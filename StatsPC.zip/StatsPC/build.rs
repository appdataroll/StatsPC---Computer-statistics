fn main() {
    if std::env::var_os("CARGO_CFG_WINDOWS").is_some() {
        let mut res = winres::WindowsResource::new();
        res.set_icon("static/icon.ico");
        res.set("ProductName", "StatsPC");
        res.set("FileDescription", "StatsPC - Real-time PC Telemetry & Hardware Specs");
        res.compile().expect("Failed to compile Windows icon resource");
    }
}
