use chrono::Local;
use serde::Serialize;
use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::time::{Duration, Instant};
use sysinfo::Disks;
use winreg::enums::{HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE, KEY_READ};
use winreg::RegKey;

#[derive(Serialize, Clone)]
pub struct HeavyApp {
    pub name: String,
    pub size_bytes: u64,
    pub location: String,
    pub kind: String, // "game" | "app"
}

#[derive(Serialize, Clone)]
pub struct HeavyFolder {
    pub name: String,
    pub path: String,
    pub size_bytes: u64,
}

#[derive(Serialize, Clone)]
pub struct DiskHeavyReport {
    pub top_apps: Vec<HeavyApp>,
    pub top_folders: Vec<HeavyFolder>,
    pub min_gb: u64,
    pub scanned_at: String,
}

pub struct DiskHeavyScanner {
    // Store raw scan (>= 50 MB) so changing min_gb filter is instant without rescanning
    cache: Mutex<Option<DiskHeavyReport>>,
}

impl DiskHeavyScanner {
    pub fn new() -> Self {
        Self {
            cache: Mutex::new(None),
        }
    }

    pub fn get_heavy_items(&self, force_refresh: bool, min_gb: u64) -> Result<DiskHeavyReport, String> {
        let clamped_gb = min_gb.clamp(1, 1000);
        let raw = {
            let guard = self.cache.lock().map_err(|e| e.to_string())?;
            if !force_refresh {
                guard.clone()
            } else {
                None
            }
        };

        let base = match raw {
            Some(r) => r,
            None => {
                let scanned = Self::scan_now();
                let mut guard = self.cache.lock().map_err(|e| e.to_string())?;
                *guard = Some(scanned.clone());
                scanned
            }
        };

        let min_bytes = clamped_gb * 1024 * 1024 * 1024;
        let top_apps: Vec<HeavyApp> = base
            .top_apps
            .into_iter()
            .filter(|a| a.size_bytes >= min_bytes)
            .take(25)
            .collect();
        let top_folders: Vec<HeavyFolder> = base
            .top_folders
            .into_iter()
            .filter(|f| f.size_bytes >= min_bytes)
            .take(25)
            .collect();

        Ok(DiskHeavyReport {
            top_apps,
            top_folders,
            min_gb: clamped_gb,
            scanned_at: base.scanned_at,
        })
    }

    fn scan_now() -> DiskHeavyReport {
        let mut apps: HashMap<String, HeavyApp> = HashMap::new();

        // 1. Registry Uninstall entries
        let reg_roots = [
            (HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
            (HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
            (HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        ];

        for (hive, subkey) in reg_roots {
            if let Ok(key) = RegKey::predef(hive).open_subkey_with_flags(subkey, KEY_READ) {
                for sub_name in key.enum_keys().flatten() {
                    if let Ok(sk) = key.open_subkey_with_flags(&sub_name, KEY_READ) {
                        let name: String = sk.get_value("DisplayName").unwrap_or_default();
                        let size_kb: u32 = sk.get_value("EstimatedSize").unwrap_or(0);
                        let loc: String = sk.get_value("InstallLocation").unwrap_or_default();
                        let clean_name = name.trim().to_string();
                        if !clean_name.is_empty() && size_kb > 0 {
                            let size_bytes = (size_kb as u64) * 1024;
                            let low_loc = loc.to_lowercase();
                            let is_game = sub_name.starts_with("Steam App ")
                                || low_loc.contains("steamapps")
                                || low_loc.contains("epic games")
                                || low_loc.contains("\\games\\");
                            Self::upsert_app(
                                &mut apps,
                                HeavyApp {
                                    name: clean_name,
                                    size_bytes,
                                    location: loc.trim().to_string(),
                                    kind: if is_game { "game" } else { "app" }.to_string(),
                                },
                            );
                        }
                    }
                }
            }
        }

        // 2. Steam libraries (appmanifest_*.acf)
        Self::scan_steam_games(&mut apps);

        // 3. Epic Games manifests
        Self::scan_epic_games(&mut apps);

        let mut top_apps: Vec<HeavyApp> = apps.into_values().collect();
        top_apps.sort_by(|a, b| b.size_bytes.cmp(&a.size_bytes));
        top_apps.truncate(60);

        // 4. Largest folders across drives
        let skip_names: HashSet<&str> = [
            "windows",
            "$recycle.bin",
            "system volume information",
            "recovery",
            "perflogs",
            "config.msi",
            "msocache",
        ]
        .into_iter()
        .collect();

        let sys_drive = std::env::var("SystemDrive").unwrap_or_else(|_| "C:".to_string());
        let sys_root = format!("{sys_drive}\\");
        let mut candidate_parents: Vec<PathBuf> = vec![PathBuf::from(&sys_root)];
        for rel in ["Program Files", "Program Files (x86)", "Games"] {
            let p = Path::new(&sys_root).join(rel);
            if p.is_dir() {
                candidate_parents.push(p);
            }
        }
        if let Ok(home) = std::env::var("USERPROFILE") {
            let home_p = PathBuf::from(&home);
            if home_p.is_dir() {
                candidate_parents.push(home_p.clone());
            }
            for sub in [r"AppData\Local", r"AppData\Roaming"] {
                let p = home_p.join(sub);
                if p.is_dir() {
                    candidate_parents.push(p);
                }
            }
        }

        let disks = Disks::new_with_refreshed_list();
        for d in &disks {
            let mount = d.mount_point();
            if !mount.as_os_str().eq_ignore_ascii_case(&sys_root) && d.total_space() > 0 {
                candidate_parents.push(mount.to_path_buf());
                for rel in ["Games", "SteamLibrary\\steamapps\\common", "Program Files"] {
                    let p = mount.join(rel);
                    if p.is_dir() {
                        candidate_parents.push(p);
                    }
                }
            }
        }

        let mut folders: Vec<HeavyFolder> = Vec::new();
        let mut seen_paths: HashSet<String> = HashSet::new();
        let total_deadline = Instant::now() + Duration::from_millis(3600);

        for parent in candidate_parents {
            if Instant::now() > total_deadline {
                break;
            }
            let Ok(entries) = fs::read_dir(&parent) else {
                continue;
            };
            for entry in entries.flatten() {
                if Instant::now() > total_deadline {
                    break;
                }
                let Ok(ft) = entry.file_type() else {
                    continue;
                };
                if !ft.is_dir() || ft.is_symlink() {
                    continue;
                }
                let name = entry.file_name().to_string_lossy().to_string();
                let low = name.to_lowercase();
                if skip_names.contains(low.as_str())
                    || low == "appdata"
                    || low == "program files"
                    || low == "program files (x86)"
                    || low == "users"
                    || low == "programdata"
                {
                    continue;
                }
                let full_path = entry.path();
                let norm = full_path.to_string_lossy().to_lowercase();
                if !seen_paths.insert(norm) {
                    continue;
                }
                let per_dir_deadline = (Instant::now() + Duration::from_millis(380)).min(total_deadline);
                let sz = dir_size_bounded(&full_path, per_dir_deadline);
                if sz >= 256 * 1024 * 1024 {
                    folders.push(HeavyFolder {
                        name,
                        path: full_path.to_string_lossy().to_string(),
                        size_bytes: sz,
                    });
                }
            }
        }

        folders.sort_by(|a, b| b.size_bytes.cmp(&a.size_bytes));
        folders.truncate(60);

        DiskHeavyReport {
            top_apps,
            top_folders: folders,
            min_gb: 1,
            scanned_at: Local::now().format("%H:%M:%S").to_string(),
        }
    }

    fn upsert_app(apps: &mut HashMap<String, HeavyApp>, item: HeavyApp) {
        let replace = apps
            .get(&item.name)
            .map(|prev| item.size_bytes > prev.size_bytes)
            .unwrap_or(true);
        if replace {
            apps.insert(item.name.clone(), item);
        }
    }

    fn scan_steam_games(apps: &mut HashMap<String, HeavyApp>) {
        let mut steam_roots = Vec::new();
        if let Ok(key) = RegKey::predef(HKEY_CURRENT_USER).open_subkey_with_flags(r"Software\Valve\Steam", KEY_READ) {
            if let Ok(path) = key.get_value::<String, _>("SteamPath") {
                steam_roots.push(PathBuf::from(path));
            }
        }
        let default_steam = PathBuf::from(r"C:\Program Files (x86)\Steam");
        if default_steam.is_dir() {
            steam_roots.push(default_steam);
        }

        let mut lib_folders = Vec::new();
        for root in steam_roots {
            let sa = root.join("steamapps");
            if sa.is_dir() {
                lib_folders.push(sa.clone());
            }
            let vdf = sa.join("libraryfolders.vdf");
            if let Ok(txt) = fs::read_to_string(vdf) {
                for line in txt.lines() {
                    let trimmed = line.trim();
                    if trimmed.starts_with("\"path\"") {
                        if let Some(val) = trimmed.split('"').nth(3) {
                            let clean = val.replace("\\\\", "\\");
                            let p = PathBuf::from(clean).join("steamapps");
                            if p.is_dir() {
                                lib_folders.push(p);
                            }
                        }
                    }
                }
            }
        }

        let mut seen_libs = HashSet::new();
        for lib in lib_folders {
            let norm = lib.to_string_lossy().to_lowercase();
            if !seen_libs.insert(norm) {
                continue;
            }
            let Ok(entries) = fs::read_dir(&lib) else {
                continue;
            };
            for entry in entries.flatten() {
                let fname = entry.file_name().to_string_lossy().to_string();
                if !fname.starts_with("appmanifest_") || !fname.ends_with(".acf") {
                    continue;
                }
                let Ok(txt) = fs::read_to_string(entry.path()) else {
                    continue;
                };
                let mut name = String::new();
                let mut size_bytes = 0u64;
                let mut installdir = String::new();
                for line in txt.lines() {
                    let parts: Vec<&str> = line.split('"').collect();
                    if parts.len() >= 4 {
                        match parts[1] {
                            "name" => name = parts[3].trim().to_string(),
                            "SizeOnDisk" => size_bytes = parts[3].trim().parse::<u64>().unwrap_or(0),
                            "installdir" => installdir = parts[3].trim().to_string(),
                            _ => {}
                        }
                    }
                }
                if !name.is_empty() && size_bytes > 0 {
                    let loc = if !installdir.is_empty() {
                        lib.join("common").join(installdir).to_string_lossy().to_string()
                    } else {
                        lib.to_string_lossy().to_string()
                    };
                    Self::upsert_app(
                        apps,
                        HeavyApp {
                            name,
                            size_bytes,
                            location: loc,
                            kind: "game".to_string(),
                        },
                    );
                }
            }
        }
    }

    fn scan_epic_games(apps: &mut HashMap<String, HeavyApp>) {
        let manifests_dir = PathBuf::from(r"C:\ProgramData\Epic\EpicGamesLauncher\Data\Manifests");
        let Ok(entries) = fs::read_dir(manifests_dir) else {
            return;
        };
        for entry in entries.flatten() {
            if entry.path().extension().and_then(|e| e.to_str()) != Some("item") {
                continue;
            }
            let Ok(txt) = fs::read_to_string(entry.path()) else {
                continue;
            };
            let Ok(val) = serde_json::from_str::<serde_json::Value>(&txt) else {
                continue;
            };
            let name = val.get("DisplayName").and_then(|v| v.as_str()).unwrap_or("").trim().to_string();
            let size_bytes = val.get("InstallSize").and_then(|v| v.as_u64()).unwrap_or(0);
            let loc = val.get("InstallLocation").and_then(|v| v.as_str()).unwrap_or("").trim().to_string();
            if !name.is_empty() && size_bytes > 0 {
                Self::upsert_app(
                    apps,
                    HeavyApp {
                        name,
                        size_bytes,
                        location: loc,
                        kind: "game".to_string(),
                    },
                );
            }
        }
    }
}

fn dir_size_bounded(root: &Path, deadline: Instant) -> u64 {
    let mut total = 0u64;
    let mut stack = vec![root.to_path_buf()];
    while let Some(curr) = stack.pop() {
        if Instant::now() > deadline {
            break;
        }
        let Ok(entries) = fs::read_dir(&curr) else {
            continue;
        };
        for entry in entries.flatten() {
            if Instant::now() > deadline {
                break;
            }
            let Ok(ft) = entry.file_type() else {
                continue;
            };
            if ft.is_symlink() {
                continue;
            }
            if ft.is_file() {
                if let Ok(meta) = entry.metadata() {
                    total += meta.len();
                }
            } else if ft.is_dir() {
                stack.push(entry.path());
            }
        }
    }
    total
}
