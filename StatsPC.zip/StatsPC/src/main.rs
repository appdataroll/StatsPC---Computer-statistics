#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod analyzer;
mod disk_heavy;
mod hardware;
mod internet;
mod server;

use crate::disk_heavy::DiskHeavyScanner;
use crate::hardware::HardwareCollector;
use crate::server::{
    find_free_port, load_saved_lang, load_saved_theme_mode, settings_dir, start_http_server,
    ServerAction, ICON_PNG,
};
use std::sync::Arc;
use tao::dpi::LogicalSize;
use tao::event::{Event, StartCause, WindowEvent};
use tao::event_loop::{ControlFlow, EventLoopBuilder};
use tao::platform::windows::WindowExtWindows;
use tao::window::{Icon, WindowBuilder};
use tray_icon::menu::{Menu, MenuEvent, MenuItem};
use tray_icon::{Icon as TrayIconImg, MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent};
use windows::Win32::Foundation::HWND;
use windows::Win32::Graphics::Dwm::{
    DwmSetWindowAttribute, DWMWA_BORDER_COLOR, DWMWA_CAPTION_COLOR, DWMWA_TEXT_COLOR,
    DWMWA_USE_IMMERSIVE_DARK_MODE,
};
use wry::{WebContext, WebViewBuilder};

enum UserEvent {
    Quit,
    MinimizeToTray,
    UpdateLang(String),
    UpdateTheme(String),
    UpdateTooltip(String),
    TrayOpen,
    TrayExit,
}

fn apply_titlebar_theme(window: &tao::window::Window, mode: &str) {
    let is_light = mode == "light";
    unsafe {
        let hwnd = HWND(window.hwnd() as *mut core::ffi::c_void);
        let dark_mode: i32 = if is_light { 0 } else { 1 };
        let _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_USE_IMMERSIVE_DARK_MODE,
            &dark_mode as *const i32 as *const _,
            std::mem::size_of::<i32>() as u32,
        );
        // COLORREF = 0x00BBGGRR: #EEF2F7 -> 0x00F7F2EE | #030712 -> 0x00120703
        let caption_color: u32 = if is_light { 0x00F7_F2EE } else { 0x0012_0703 };
        let _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_CAPTION_COLOR,
            &caption_color as *const u32 as *const _,
            std::mem::size_of::<u32>() as u32,
        );
        let text_color: u32 = if is_light { 0x002A_170F } else { 0x00FC_FAF8 };
        let _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_TEXT_COLOR,
            &text_color as *const u32 as *const _,
            std::mem::size_of::<u32>() as u32,
        );
        let border_color: u32 = if is_light { 0x00E1_D5CB } else { 0x003B_291E };
        let _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_BORDER_COLOR,
            &border_color as *const u32 as *const _,
            std::mem::size_of::<u32>() as u32,
        );
    }
}

fn load_window_icon() -> Option<Icon> {
    let img = image::load_from_memory(ICON_PNG).ok()?.into_rgba8();
    let (w, h) = img.dimensions();
    Icon::from_rgba(img.into_raw(), w, h).ok()
}

fn load_tray_icon() -> Option<TrayIconImg> {
    let img = image::load_from_memory(ICON_PNG)
        .ok()?
        .resize_exact(32, 32, image::imageops::FilterType::Lanczos3)
        .into_rgba8();
    let (w, h) = img.dimensions();
    TrayIconImg::from_rgba(img.into_raw(), w, h).ok()
}

fn tray_labels(lang: &str) -> (&'static str, &'static str) {
    if lang == "ru" {
        ("Открыть StatsPC", "Закрыть")
    } else {
        ("Open StatsPC", "Exit")
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut preferred_port: u16 = 8765;
    let mut no_browser = false;
    let mut cli_minimized = false;

    let mut i = 1;
    while i < args.len() {
        if args[i] == "--no-browser" {
            no_browser = true;
        } else if args[i] == "--minimized" {
            cli_minimized = true;
        } else if args[i] == "--port" && i + 1 < args.len() {
            if let Ok(p) = args[i + 1].parse::<u16>() {
                preferred_port = p;
            }
            i += 1;
        }
        i += 1;
    }

    // Only start hidden in tray when launched with --minimized (e.g. from Windows Startup).
    // Manual double-click launches always show the window.
    let start_minimized = cli_minimized;

    let port = find_free_port(preferred_port);
    let collector = Arc::new(HardwareCollector::new());
    let disk_scanner = Arc::new(DiskHeavyScanner::new());

    // Warm up WMI hardware inventory in background so window opens immediately
    let hw_warmup = Arc::clone(&collector);
    std::thread::spawn(move || {
        let _ = hw_warmup.get_hardware_inventory(false);
    });

    if no_browser {
        let on_action: Arc<dyn Fn(ServerAction) + Send + Sync> = Arc::new(|act| {
            if matches!(act, ServerAction::Shutdown) {
                std::process::exit(0);
            }
        });
        let _ = start_http_server(port, collector, disk_scanner, on_action);
        return;
    }

    let event_loop = EventLoopBuilder::<UserEvent>::with_user_event().build();
    let proxy_srv = event_loop.create_proxy();

    let server_collector = Arc::clone(&collector);
    let server_disk = Arc::clone(&disk_scanner);
    let on_action: Arc<dyn Fn(ServerAction) + Send + Sync> = Arc::new(move |act| match act {
        ServerAction::Shutdown => {
            let _ = proxy_srv.send_event(UserEvent::Quit);
            std::thread::spawn(|| {
                std::thread::sleep(std::time::Duration::from_millis(400));
                std::process::exit(0);
            });
        }
        ServerAction::MinimizeToTray => {
            let _ = proxy_srv.send_event(UserEvent::MinimizeToTray);
        }
        ServerAction::UpdateLang(lang) => {
            let _ = proxy_srv.send_event(UserEvent::UpdateLang(lang));
        }
        ServerAction::UpdateTheme(mode) => {
            let _ = proxy_srv.send_event(UserEvent::UpdateTheme(mode));
        }
    });

    std::thread::spawn(move || {
        let _ = start_http_server(port, server_collector, server_disk, on_action);
    });

    let mut builder = WindowBuilder::new()
        .with_title("StatsPC")
        .with_inner_size(LogicalSize::new(1380.0, 900.0))
        .with_min_inner_size(LogicalSize::new(960.0, 640.0))
        .with_visible(!start_minimized);

    if let Some(icon) = load_window_icon() {
        builder = builder.with_window_icon(Some(icon));
    }

    let window = builder.build(&event_loop).expect("Failed to create window");

    let init_theme = load_saved_theme_mode();
    apply_titlebar_theme(&window, &init_theme);

    // Build System Tray icon & menu
    let init_lang = load_saved_lang();
    let (open_lbl, exit_lbl) = tray_labels(&init_lang);
    let tray_menu = Menu::new();
    let open_item = MenuItem::new(open_lbl, true, None);
    let exit_item = MenuItem::new(exit_lbl, true, None);
    let _ = tray_menu.append(&open_item);
    let _ = tray_menu.append(&exit_item);

    let open_id = open_item.id().clone();
    let exit_id = exit_item.id().clone();

    let proxy_menu = event_loop.create_proxy();
    MenuEvent::set_event_handler(Some(move |ev: MenuEvent| {
        if ev.id == open_id {
            let _ = proxy_menu.send_event(UserEvent::TrayOpen);
        } else if ev.id == exit_id {
            let _ = proxy_menu.send_event(UserEvent::TrayExit);
        }
    }));

    let proxy_tray = event_loop.create_proxy();
    TrayIconEvent::set_event_handler(Some(move |ev: TrayIconEvent| {
        if let TrayIconEvent::Click {
            button: MouseButton::Left,
            button_state: MouseButtonState::Up,
            ..
        }
        | TrayIconEvent::DoubleClick {
            button: MouseButton::Left,
            ..
        } = ev
        {
            let _ = proxy_tray.send_event(UserEvent::TrayOpen);
        }
    }));

    let mut tray_icon_opt: Option<tray_icon::TrayIcon> = None;
    let mut tray_menu_opt = Some(tray_menu);

    let cache_dir = settings_dir().join("webview_cache");
    let _ = std::fs::create_dir_all(&cache_dir);
    let mut web_context = WebContext::new(Some(cache_dir));

    let url = format!("http://127.0.0.1:{port}");
    let webview = WebViewBuilder::with_web_context(&mut web_context)
        .with_url(&url)
        .with_background_color((3, 7, 18, 255))
        .build(&window)
        .expect("Failed to build WebView");

    let proxy_tip = event_loop.create_proxy();
    let tip_collector = Arc::clone(&collector);
    std::thread::spawn(move || loop {
        std::thread::sleep(std::time::Duration::from_secs(2));
        let (cpu, ram, gpu_temp) = tip_collector.get_tray_snapshot();
        let tip = match gpu_temp {
            Some(t) => format!("StatsPC • CPU {:.0}% • RAM {:.0}% • GPU {:.0}°C", cpu, ram, t),
            None => format!("StatsPC • CPU {:.0}% • RAM {:.0}%", cpu, ram),
        };
        let _ = proxy_tip.send_event(UserEvent::UpdateTooltip(tip));
    });

    event_loop.run(move |event, _, control_flow| {
        *control_flow = ControlFlow::Wait;
        match event {
            Event::NewEvents(StartCause::Init) => {
                if tray_icon_opt.is_none() {
                    if let (Some(menu), Some(icon)) = (tray_menu_opt.take(), load_tray_icon()) {
                        tray_icon_opt = TrayIconBuilder::new()
                            .with_menu(Box::new(menu))
                            .with_tooltip("StatsPC")
                            .with_icon(icon)
                            .build()
                            .ok();
                    }
                }
            }
            Event::WindowEvent {
                event: WindowEvent::CloseRequested,
                ..
            } => {
                if webview
                    .evaluate_script("window.__onCloseRequested && window.__onCloseRequested();")
                    .is_err()
                {
                    window.set_visible(false);
                }
            }
            Event::UserEvent(UserEvent::MinimizeToTray) => {
                window.set_visible(false);
            }
            Event::UserEvent(UserEvent::TrayOpen) => {
                window.set_visible(true);
                window.set_minimized(false);
                window.set_focus();
            }
            Event::UserEvent(UserEvent::UpdateLang(lang)) => {
                let (o, e) = tray_labels(&lang);
                open_item.set_text(o);
                exit_item.set_text(e);
            }
            Event::UserEvent(UserEvent::UpdateTheme(mode)) => {
                apply_titlebar_theme(&window, &mode);
            }
            Event::UserEvent(UserEvent::UpdateTooltip(tip)) => {
                if let Some(ref tray) = tray_icon_opt {
                    let _ = tray.set_tooltip(Some(tip));
                }
            }
            Event::UserEvent(UserEvent::Quit) | Event::UserEvent(UserEvent::TrayExit) => {
                *control_flow = ControlFlow::Exit;
                std::process::exit(0);
            }
            _ => {}
        }
    });
}
