use crate::analyzer::run_pc_analysis;
use crate::disk_heavy::DiskHeavyScanner;
use crate::hardware::HardwareCollector;
use crate::internet::{collect_net_info, run_speed_test};
use serde::Serialize;
use serde_json::Value;
use std::fs;
use std::net::TcpListener;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use tiny_http::{Header, Method, Response, Server, StatusCode};
use winreg::enums::{HKEY_CURRENT_USER, KEY_READ, KEY_WRITE};
use winreg::RegKey;

static INDEX_HTML: &[u8] = include_bytes!("../static/index.html");
static STYLES_CSS: &[u8] = include_bytes!("../static/styles.css");
static APP_JS: &[u8] = include_bytes!("../static/app.js");
pub static ICON_PNG: &[u8] = include_bytes!("../static/icon.png");
static ICON_ICO: &[u8] = include_bytes!("../static/icon.ico");

#[derive(Serialize)]
struct ExportReport<H, L> {
    hardware: H,
    live_snapshot: L,
}

pub fn settings_dir() -> PathBuf {
    let base = std::env::var("LOCALAPPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from("."));
    base.join("StatsPC")
}

fn settings_file() -> PathBuf {
    settings_dir().join("settings.json")
}

pub fn find_free_port(preferred: u16) -> u16 {
    if preferred > 0 && TcpListener::bind(("127.0.0.1", preferred)).is_ok() {
        return preferred;
    }
    if let Ok(listener) = TcpListener::bind(("127.0.0.1", 0)) {
        if let Ok(addr) = listener.local_addr() {
            return addr.port();
        }
    }
    8765
}

pub fn load_saved_lang() -> String {
    fs::read_to_string(settings_file())
        .ok()
        .and_then(|s| serde_json::from_str::<Value>(&s).ok())
        .and_then(|v| v.get("lang").and_then(|l| l.as_str()).map(|s| s.to_string()))
        .unwrap_or_else(|| "en".to_string())
}

pub fn load_saved_theme_mode() -> String {
    fs::read_to_string(settings_file())
        .ok()
        .and_then(|s| serde_json::from_str::<Value>(&s).ok())
        .and_then(|v| v.get("themeMode").and_then(|m| m.as_str()).map(|s| s.to_string()))
        .unwrap_or_else(|| "dark".to_string())
}

pub fn load_saved_start_minimized() -> bool {
    fs::read_to_string(settings_file())
        .ok()
        .and_then(|s| serde_json::from_str::<Value>(&s).ok())
        .and_then(|v| v.get("startMinimized").and_then(|b| b.as_bool()))
        .unwrap_or(false)
}

const RUN_REG_PATH: &str = r"Software\Microsoft\Windows\CurrentVersion\Run";
const RUN_VALUE_NAME: &str = "StatsPC";

pub fn is_autostart_enabled() -> bool {
    let Ok(hkcu) = RegKey::predef(HKEY_CURRENT_USER).open_subkey_with_flags(RUN_REG_PATH, KEY_READ) else {
        return false;
    };
    let val: Result<String, _> = hkcu.get_value(RUN_VALUE_NAME);
    val.map(|s| !s.trim().is_empty()).unwrap_or(false)
}

pub fn set_autostart(enabled: bool, start_minimized: bool) -> Result<(), String> {
    let hkcu = RegKey::predef(HKEY_CURRENT_USER)
        .open_subkey_with_flags(RUN_REG_PATH, KEY_WRITE)
        .map_err(|e| e.to_string())?;
    if enabled {
        let exe = std::env::current_exe().map_err(|e| e.to_string())?;
        let exe_str = exe.to_string_lossy();
        let cmd = if start_minimized {
            format!("\"{exe_str}\" --minimized")
        } else {
            format!("\"{exe_str}\"")
        };
        hkcu.set_value(RUN_VALUE_NAME, &cmd).map_err(|e| e.to_string())?;
    } else {
        let _ = hkcu.delete_value(RUN_VALUE_NAME);
    }
    Ok(())
}

pub enum ServerAction {
    Shutdown,
    MinimizeToTray,
    UpdateLang(String),
    UpdateTheme(String),
}

pub fn start_http_server(
    port: u16,
    collector: Arc<HardwareCollector>,
    disk_scanner: Arc<DiskHeavyScanner>,
    on_action: Arc<dyn Fn(ServerAction) + Send + Sync>,
) -> Result<(), String> {
    let addr = format!("127.0.0.1:{port}");
    let server = Server::http(&addr).map_err(|e| format!("Failed to bind {addr}: {e}"))?;
    let settings_lock = Arc::new(Mutex::new(()));

    for mut req in server.incoming_requests() {
        let collector = Arc::clone(&collector);
        let disk_scanner = Arc::clone(&disk_scanner);
        let settings_lock = Arc::clone(&settings_lock);
        let on_action = Arc::clone(&on_action);

        std::thread::spawn(move || {
            let full_url = req.url().to_string();
            let (path, query) = match full_url.split_once('?') {
                Some((p, q)) => (p, q),
                None => (full_url.as_str(), ""),
            };
            let refresh = query.split('&').any(|kv| kv == "refresh=1");

            match (req.method(), path) {
                (&Method::Get, "/") | (&Method::Get, "/index.html") => {
                    let _ = req.respond(make_bytes_resp(INDEX_HTML, "text/html; charset=utf-8"));
                }
                (&Method::Get, "/styles.css") => {
                    let _ = req.respond(make_bytes_resp(STYLES_CSS, "text/css; charset=utf-8"));
                }
                (&Method::Get, "/app.js") => {
                    let _ = req.respond(make_bytes_resp(APP_JS, "application/javascript; charset=utf-8"));
                }
                (&Method::Get, "/icon.png") => {
                    let _ = req.respond(make_bytes_resp(ICON_PNG, "image/png"));
                }
                (&Method::Get, "/icon.ico") => {
                    let _ = req.respond(make_bytes_resp(ICON_ICO, "image/x-icon"));
                }
                (&Method::Get, "/api/live") => match collector.get_live_telemetry() {
                    Ok(live) => {
                        let _ = req.respond(make_json_resp(&live, 200, None));
                    }
                    Err(e) => {
                        let _ = req.respond(make_json_resp(&serde_json::json!({"error": e}), 500, None));
                    }
                },
                (&Method::Get, "/api/hardware") => match collector.get_hardware_inventory(refresh) {
                    Ok(hw) => {
                        let _ = req.respond(make_json_resp(&hw, 200, None));
                    }
                    Err(e) => {
                        let _ = req.respond(make_json_resp(&serde_json::json!({"error": e}), 500, None));
                    }
                },
                (&Method::Get, "/api/disk-heavy") => {
                    let min_gb = query
                        .split('&')
                        .find_map(|kv| kv.strip_prefix("min_gb="))
                        .and_then(|v| v.parse::<u64>().ok())
                        .unwrap_or(1);
                    match disk_scanner.get_heavy_items(refresh, min_gb) {
                        Ok(rep) => {
                            let _ = req.respond(make_json_resp(&rep, 200, None));
                        }
                        Err(e) => {
                            let _ = req.respond(make_json_resp(&serde_json::json!({"error": e}), 500, None));
                        }
                    }
                }
                (&Method::Get, "/api/export") => {
                    match (collector.get_hardware_inventory(false), collector.get_live_telemetry()) {
                        (Ok(hw), Ok(live)) => {
                            let export = ExportReport {
                                hardware: hw,
                                live_snapshot: live,
                            };
                            let _ = req.respond(make_json_resp(
                                &export,
                                200,
                                Some("StatsPC_report.json"),
                            ));
                        }
                        (Err(e), _) | (_, Err(e)) => {
                            let _ = req.respond(make_json_resp(&serde_json::json!({"error": e}), 500, None));
                        }
                    }
                }
                (&Method::Get, "/api/settings") => {
                    let _guard = settings_lock.lock();
                    let mut val: Value = fs::read_to_string(settings_file())
                        .ok()
                        .and_then(|s| serde_json::from_str(&s).ok())
                        .unwrap_or_else(|| serde_json::json!({}));
                    if let Some(obj) = val.as_object_mut() {
                        obj.insert("autostart".to_string(), serde_json::json!(is_autostart_enabled()));
                    }
                    let _ = req.respond(make_json_resp(&val, 200, None));
                }
                (&Method::Post, "/api/settings") => {
                    let mut body = String::new();
                    if req.as_reader().read_to_string(&mut body).is_ok() {
                        if let Ok(val) = serde_json::from_str::<Value>(&body) {
                            if val.is_object() {
                                let _guard = settings_lock.lock();
                                let _ = fs::create_dir_all(settings_dir());
                                if let Ok(pretty) = serde_json::to_string_pretty(&val) {
                                    let _ = fs::write(settings_file(), pretty);
                                }
                                if let Some(auto) = val.get("autostart").and_then(|v| v.as_bool()) {
                                    let min_tray = val
                                        .get("startMinimized")
                                        .and_then(|v| v.as_bool())
                                        .unwrap_or(false);
                                    let _ = set_autostart(auto, min_tray);
                                }
                                if let Some(lang) = val.get("lang").and_then(|v| v.as_str()) {
                                    on_action(ServerAction::UpdateLang(lang.to_string()));
                                }
                                if let Some(mode) = val.get("themeMode").and_then(|v| v.as_str()) {
                                    on_action(ServerAction::UpdateTheme(mode.to_string()));
                                }
                                let _ = req.respond(make_json_resp(&serde_json::json!({"ok": true}), 200, None));
                                return;
                            }
                        }
                    }
                    let _ = req.respond(make_json_resp(
                        &serde_json::json!({"error": "Invalid JSON object"}),
                        400,
                        None,
                    ));
                }
                (&Method::Get, "/api/net-info") => {
                    let rep = collect_net_info();
                    let _ = req.respond(make_json_resp(&rep, 200, None));
                }
                (&Method::Get, "/api/speedtest") => {
                    let rep = run_speed_test();
                    let _ = req.respond(make_json_resp(&rep, 200, None));
                }
                (&Method::Get, "/api/analyze") => match run_pc_analysis(&collector, &disk_scanner) {
                    Ok(rep) => {
                        let _ = req.respond(make_json_resp(&rep, 200, None));
                    }
                    Err(e) => {
                        let _ = req.respond(make_json_resp(&serde_json::json!({"error": e}), 500, None));
                    }
                }
                (&Method::Get, "/api/minimize-tray") => {
                    on_action(ServerAction::MinimizeToTray);
                    let _ = req.respond(make_json_resp(
                        &serde_json::json!({"status": "minimized_to_tray"}),
                        200,
                        None,
                    ));
                }
                (&Method::Get, "/api/shutdown") => {
                    let _ = req.respond(make_json_resp(
                        &serde_json::json!({"status": "shutting_down"}),
                        200,
                        None,
                    ));
                    std::thread::spawn(move || {
                        std::thread::sleep(std::time::Duration::from_millis(180));
                        on_action(ServerAction::Shutdown);
                    });
                }
                _ => {
                    let resp = Response::from_string("Not Found").with_status_code(StatusCode(404));
                    let _ = req.respond(resp);
                }
            }
        });
    }
    Ok(())
}

fn make_bytes_resp(data: &'static [u8], content_type: &str) -> Response<std::io::Cursor<Vec<u8>>> {
    let mut resp = Response::from_data(data).with_status_code(StatusCode(200));
    if let Ok(h) = Header::from_bytes("Content-Type", content_type) {
        resp.add_header(h);
    }
    if let Ok(h) = Header::from_bytes("Cache-Control", "no-store") {
        resp.add_header(h);
    }
    resp
}

fn make_json_resp<T: Serialize>(
    payload: &T,
    status: u16,
    download_name: Option<&str>,
) -> Response<std::io::Cursor<Vec<u8>>> {
    let body = serde_json::to_vec_pretty(payload).unwrap_or_else(|_| b"{}".to_vec());
    let mut resp = Response::from_data(body).with_status_code(StatusCode(status));
    if let Ok(h) = Header::from_bytes("Content-Type", "application/json; charset=utf-8") {
        resp.add_header(h);
    }
    if let Ok(h) = Header::from_bytes("Cache-Control", "no-store") {
        resp.add_header(h);
    }
    if let Some(name) = download_name {
        if let Ok(h) = Header::from_bytes(
            "Content-Disposition",
            format!("attachment; filename=\"{name}\""),
        ) {
            resp.add_header(h);
        }
    }
    resp
}
