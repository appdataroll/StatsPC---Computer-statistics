use crate::disk_heavy::DiskHeavyScanner;
use crate::hardware::HardwareCollector;
use chrono::{Local, NaiveDate};
use serde::Serialize;

#[derive(Serialize, Clone)]
pub struct Recommendation {
    pub severity: String, // "critical" | "warning" | "tip"
    pub category: String, // "disk" | "ram" | "cpu" | "gpu" | "monitor" | "system"
    pub title_en: String,
    pub title_ru: String,
    pub detail_en: String,
    pub detail_ru: String,
    pub metric: String,
}

#[derive(Serialize, Clone)]
pub struct CheckSummary {
    pub label_en: String,
    pub label_ru: String,
    pub status: String, // "ok" | "warning" | "critical"
    pub value: String,
}

#[derive(Serialize, Clone)]
pub struct AnalysisReport {
    pub score: u8,
    pub status: String, // "ideal" | "good" | "attention"
    pub recommendations: Vec<Recommendation>,
    pub checks: Vec<CheckSummary>,
    pub analyzed_at: String,
}

pub fn run_pc_analysis(
    collector: &HardwareCollector,
    disk_scanner: &DiskHeavyScanner,
) -> Result<AnalysisReport, String> {
    let hw = collector.get_hardware_inventory(false)?;
    let live = collector.get_live_telemetry()?;
    let heavy = disk_scanner.get_heavy_items(false, 1).ok();

    let mut recs: Vec<Recommendation> = Vec::new();
    let mut checks: Vec<CheckSummary> = Vec::new();
    let mut score: i32 = 100;

    // 1. Storage partitions check
    let mut worst_disk_status = "ok";
    let mut worst_disk_val = String::new();
    for p in &live.disk.partitions {
        let free_gb = (p.free_bytes as f64) / (1024.0 * 1024.0 * 1024.0);
        let drive_label = p.mountpoint.trim_end_matches('\\');
        if worst_disk_val.is_empty() || p.percent > 80.0 {
            worst_disk_val = format!("{drive_label} {:.0}% ({:.1} GB free)", p.percent, free_gb);
        }

        // Find heaviest folder on this drive if available
        let heavy_hint = heavy.as_ref().and_then(|h| {
            h.top_folders
                .iter()
                .find(|f| f.path.to_lowercase().starts_with(&drive_label.to_lowercase()))
                .map(|f| {
                    let gb = (f.size_bytes as f64) / (1024.0 * 1024.0 * 1024.0);
                    (f.name.clone(), gb)
                })
        });

        if p.percent >= 90.0 || free_gb < 15.0 {
            worst_disk_status = "critical";
            score -= 18;
            let extra_en = heavy_hint
                .as_ref()
                .map(|(n, gb)| format!(" Largest folder: {n} ({gb:.1} GB)."))
                .unwrap_or_default();
            let extra_ru = heavy_hint
                .as_ref()
                .map(|(n, gb)| format!(" Крупнейшая папка: {n} ({gb:.1} ГБ)."))
                .unwrap_or_default();
            recs.push(Recommendation {
                severity: "critical".to_string(),
                category: "disk".to_string(),
                title_en: format!("Free up space on drive {drive_label}"),
                title_ru: format!("Освободите место на диске {drive_label}"),
                detail_en: format!(
                    "Only {free_gb:.1} GB free ({:.1}% used). Low space slows down Windows and apps.{extra_en}",
                    p.percent
                ),
                detail_ru: format!(
                    "Осталось всего {free_gb:.1} ГБ (занято {:.1}%). Нехватка места замедляет систему.{extra_ru}",
                    p.percent
                ),
                metric: format!("{:.1}%", p.percent),
            });
        } else if p.percent >= 80.0 {
            if worst_disk_status == "ok" {
                worst_disk_status = "warning";
            }
            score -= 9;
            let extra_en = heavy_hint
                .as_ref()
                .map(|(n, gb)| format!(" Largest folder: {n} ({gb:.1} GB)."))
                .unwrap_or_default();
            let extra_ru = heavy_hint
                .as_ref()
                .map(|(n, gb)| format!(" Крупнейшая папка: {n} ({gb:.1} ГБ)."))
                .unwrap_or_default();
            recs.push(Recommendation {
                severity: "warning".to_string(),
                category: "disk".to_string(),
                title_en: format!("Drive {drive_label} is filling up"),
                title_ru: format!("Рекомендуется очистить диск {drive_label}"),
                detail_en: format!(
                    "Used {:.1}% ({free_gb:.1} GB free). Consider cleaning temporary files or unused games.{extra_en}",
                    p.percent
                ),
                detail_ru: format!(
                    "Занято {:.1}% (свободно {free_gb:.1} ГБ). Стоит удалить ненужные файлы или игры.{extra_ru}",
                    p.percent
                ),
                metric: format!("{:.1}%", p.percent),
            });
        }
    }
    checks.push(CheckSummary {
        label_en: "Storage Drives".to_string(),
        label_ru: "Накопители".to_string(),
        status: worst_disk_status.to_string(),
        value: if worst_disk_val.is_empty() { "OK".to_string() } else { worst_disk_val },
    });

    // 2. RAM checks (usage, single-channel, XMP speed, total capacity)
    let total_ram_gb = (live.memory.total_bytes as f64) / (1024.0 * 1024.0 * 1024.0);
    let mut ram_status = "ok";
    if live.memory.percent >= 85.0 {
        ram_status = "warning";
        score -= 10;
        recs.push(Recommendation {
            severity: "warning".to_string(),
            category: "ram".to_string(),
            title_en: "High RAM usage".to_string(),
            title_ru: "Высокая загрузка оперативной памяти".to_string(),
            detail_en: format!(
                "RAM usage is at {:.1}% ({:.1} GB total). Close unused background apps to prevent stuttering.",
                live.memory.percent, total_ram_gb
            ),
            detail_ru: format!(
                "Память загружена на {:.1}% (всего {total_ram_gb:.0} ГБ). Закройте лишние фоновые программы.",
                live.memory.percent
            ),
            metric: format!("{:.1}%", live.memory.percent),
        });
    }
    if hw.ram_modules.len() == 1 {
        if ram_status == "ok" {
            ram_status = "warning";
        }
        score -= 8;
        recs.push(Recommendation {
            severity: "tip".to_string(),
            category: "ram".to_string(),
            title_en: "RAM is running in single-channel mode".to_string(),
            title_ru: "Память работает в одноканальном режиме".to_string(),
            detail_en: "Only 1 RAM module is installed. Adding a matching second stick significantly improves CPU & gaming performance.".to_string(),
            detail_ru: "Установлен только 1 модуль ОЗУ. Добавление второй аналогичной планки заметно повысит производительность.".to_string(),
            metric: "1 DIMM".to_string(),
        });
    }
    if let Some(m) = hw.ram_modules.first() {
        if m.speed_mhz > 0 && m.configured_speed_mhz > 0 && m.configured_speed_mhz < m.speed_mhz {
            score -= 4;
            recs.push(Recommendation {
                severity: "tip".to_string(),
                category: "ram".to_string(),
                title_en: "RAM is running below rated speed".to_string(),
                title_ru: "ОЗУ работает ниже номинальной частоты".to_string(),
                detail_en: format!(
                    "Current speed is {} MT/s, while rated speed is {} MT/s. Check XMP/EXPO profile in BIOS.",
                    m.configured_speed_mhz, m.speed_mhz
                ),
                detail_ru: format!(
                    "Текущая частота {} МТ/с при номинале {} МТ/с. Проверьте профиль XMP/EXPO в BIOS.",
                    m.configured_speed_mhz, m.speed_mhz
                ),
                metric: format!("{} MT/s", m.configured_speed_mhz),
            });
        }
    }
    if total_ram_gb > 0.0 && total_ram_gb < 15.0 {
        score -= 5;
        recs.push(Recommendation {
            severity: "tip".to_string(),
            category: "ram".to_string(),
            title_en: "Consider upgrading RAM capacity".to_string(),
            title_ru: "Небольшой объём оперативной памяти".to_string(),
            detail_en: format!("Installed {total_ram_gb:.0} GB. 16–32 GB is recommended for modern workloads and games."),
            detail_ru: format!("Установлено {total_ram_gb:.0} ГБ. Для современных игр и многозадачности рекомендуется 16–32 ГБ."),
            metric: format!("{total_ram_gb:.0} GB"),
        });
    }
    checks.push(CheckSummary {
        label_en: "Memory (RAM)".to_string(),
        label_ru: "Оперативная память".to_string(),
        status: ram_status.to_string(),
        value: format!("{total_ram_gb:.0} GB • {:.1}%", live.memory.percent),
    });

    // 3. CPU load check
    let mut cpu_status = "ok";
    if live.cpu.percent >= 85.0 {
        cpu_status = "warning";
        score -= 10;
        recs.push(Recommendation {
            severity: "warning".to_string(),
            category: "cpu".to_string(),
            title_en: "High CPU load detected".to_string(),
            title_ru: "Высокая нагрузка на процессор".to_string(),
            detail_en: format!("CPU is at {:.1}%. Inspect top processes in the Statistics tab.", live.cpu.percent),
            detail_ru: format!("Нагрузка CPU составляет {:.1}%. Проверьте активные процессы во вкладке «Статистика».", live.cpu.percent),
            metric: format!("{:.1}%", live.cpu.percent),
        });
    }
    checks.push(CheckSummary {
        label_en: "Processor (CPU)".to_string(),
        label_ru: "Процессор (CPU)".to_string(),
        status: cpu_status.to_string(),
        value: format!("{:.1}%", live.cpu.percent),
    });

    // 4. GPU temperature & VRAM check
    let mut gpu_status = "ok";
    let mut gpu_val = "OK".to_string();
    if let Some(g) = live.gpus_live.first() {
        let temp = g.temperature_c.unwrap_or(0.0);
        let used = g.memory_used_mb.unwrap_or(0.0);
        let total = g.memory_total_mb.unwrap_or(0.0);
        gpu_val = format!("{:.0}°C • {:.0}%", temp, g.utilization_pct.unwrap_or(0.0));
        if temp >= 83.0 {
            gpu_status = "critical";
            score -= 18;
            recs.push(Recommendation {
                severity: "critical".to_string(),
                category: "gpu".to_string(),
                title_en: "GPU temperature is too high".to_string(),
                title_ru: "Высокая температура видеокарты".to_string(),
                detail_en: format!("GPU is running at {temp:.0}°C. Check case airflow, fan curves, or clean dust."),
                detail_ru: format!("Видеокарта нагрелась до {temp:.0}°C. Проверьте вентиляторы, обдув корпуса и очистите от пыли."),
                metric: format!("{temp:.0}°C"),
            });
        } else if temp >= 75.0 {
            gpu_status = "warning";
            score -= 6;
            recs.push(Recommendation {
                severity: "tip".to_string(),
                category: "gpu".to_string(),
                title_en: "GPU is running warm".to_string(),
                title_ru: "Повышенный нагрев видеокарты".to_string(),
                detail_en: format!("GPU temperature is {temp:.0}°C. Ensure good airflow under heavy load."),
                detail_ru: format!("Температура GPU {temp:.0}°C. Следите за охлаждением под нагрузкой."),
                metric: format!("{temp:.0}°C"),
            });
        }
        if total > 0.0 && (used / total) >= 0.92 {
            if gpu_status == "ok" {
                gpu_status = "warning";
            }
            score -= 8;
            recs.push(Recommendation {
                severity: "warning".to_string(),
                category: "gpu".to_string(),
                title_en: "GPU VRAM is nearly full".to_string(),
                title_ru: "Видеопамять (VRAM) почти заполнена".to_string(),
                detail_en: format!("Using {:.1} / {:.1} GB VRAM. Lowering texture quality or closing 3D apps may help.", used / 1024.0, total / 1024.0),
                detail_ru: format!("Занято {:.1} из {:.1} ГБ VRAM. Попробуйте снизить качество текстур или закрыть лишние 3D-приложения.", used / 1024.0, total / 1024.0),
                metric: format!("{:.1} GB", used / 1024.0),
            });
        }
    }
    checks.push(CheckSummary {
        label_en: "Graphics (GPU)".to_string(),
        label_ru: "Видеокарта (GPU)".to_string(),
        status: gpu_status.to_string(),
        value: gpu_val,
    });

    // 4b. Drivers check (GPU driver version/date & device status)
    let mut drv_status = "ok";
    let mut drv_val = "OK".to_string();
    let today = Local::now().date_naive();
    for g in &hw.gpus {
        if !g.driver_version.is_empty() && drv_val == "OK" {
            drv_val = format!("v{}", g.driver_version);
        }
        if !g.status.is_empty() && g.status.to_uppercase() != "OK" {
            drv_status = "critical";
            score -= 14;
            recs.push(Recommendation {
                severity: "critical".to_string(),
                category: "driver".to_string(),
                title_en: format!("Driver issue on {}", g.name),
                title_ru: format!("Проблема с драйвером {}", g.name),
                detail_en: format!("Device status reports '{}'. Reinstall or update the display driver.", g.status),
                detail_ru: format!("Статус устройства: «{}». Переустановите или обновите драйвер.", g.status),
                metric: g.status.clone(),
            });
        } else if let Ok(drv_date) = NaiveDate::parse_from_str(&g.driver_date, "%Y-%m-%d") {
            let age_days = (today - drv_date).num_days();
            if age_days > 365 {
                if drv_status == "ok" {
                    drv_status = "warning";
                }
                score -= 4;
                recs.push(Recommendation {
                    severity: "tip".to_string(),
                    category: "driver".to_string(),
                    title_en: format!("Outdated GPU driver ({})", g.name),
                    title_ru: format!("Устаревший драйвер видеокарты ({})", g.name),
                    detail_en: format!("Driver date is {} ({} days old). Consider updating for better stability and performance.", g.driver_date, age_days),
                    detail_ru: format!("Дата драйвера {} ({} дн. назад). Рекомендуется обновление для стабильности и производительности.", g.driver_date, age_days),
                    metric: g.driver_date.clone(),
                });
            }
        }
    }
    checks.push(CheckSummary {
        label_en: "Drivers".to_string(),
        label_ru: "Драйверы".to_string(),
        status: drv_status.to_string(),
        value: drv_val,
    });

    // 5. Monitor refresh rate & native resolution check
    let mut mon_status = "ok";
    let mut mon_val = "OK".to_string();
    for m in &hw.monitors {
        if !m.current_resolution.is_empty() && m.current_hz > 0 {
            mon_val = format!("{} @ {} Hz", m.current_resolution, m.current_hz);
        }
        if m.max_hz > m.current_hz && m.current_hz > 0 {
            mon_status = "warning";
            score -= 8;
            let mname = if m.name.is_empty() { "Display".to_string() } else { m.name.clone() };
            recs.push(Recommendation {
                severity: "warning".to_string(),
                category: "monitor".to_string(),
                title_en: format!("Monitor {mname} is not at max refresh rate"),
                title_ru: format!("Монитор {mname} работает не на максимальной герцовке"),
                detail_en: format!(
                    "Currently set to {} Hz, while the display supports {} Hz. Raise it in Windows Display Settings.",
                    m.current_hz, m.max_hz
                ),
                detail_ru: format!(
                    "Сейчас выставлено {} Гц при максимуме {} Гц. Переключите частоту в настройках экрана Windows.",
                    m.current_hz, m.max_hz
                ),
                metric: format!("{} / {} Hz", m.current_hz, m.max_hz),
            });
        }
        if !m.current_resolution.is_empty() && !m.max_resolution.is_empty() && m.current_resolution != m.max_resolution {
            if mon_status == "ok" {
                mon_status = "warning";
            }
            score -= 5;
            let mname = if m.name.is_empty() { "Display".to_string() } else { m.name.clone() };
            recs.push(Recommendation {
                severity: "tip".to_string(),
                category: "monitor".to_string(),
                title_en: format!("Monitor {mname} below native resolution"),
                title_ru: format!("Разрешение монитора {mname} ниже максимального"),
                detail_en: format!("Current resolution is {}, native maximum is {}.", m.current_resolution, m.max_resolution),
                detail_ru: format!("Текущее разрешение {}, максимальное — {}.", m.current_resolution, m.max_resolution),
                metric: m.current_resolution.clone(),
            });
        }
    }
    checks.push(CheckSummary {
        label_en: "Display".to_string(),
        label_ru: "Монитор".to_string(),
        status: mon_status.to_string(),
        value: mon_val,
    });

    // 6. Uptime check
    let uptime_days = live.uptime_seconds / 86400;
    if uptime_days >= 7 {
        score -= 4;
        recs.push(Recommendation {
            severity: "tip".to_string(),
            category: "system".to_string(),
            title_en: "Long system uptime without reboot".to_string(),
            title_ru: "Долгая работа без перезагрузки".to_string(),
            detail_en: format!("System has been running for {uptime_days} days. A reboot helps keep Windows responsive."),
            detail_ru: format!("ПК не перезагружался уже {uptime_days} дн. Перезагрузка поможет очистить кэш и применить обновления."),
            metric: format!("{uptime_days}d"),
        });
    }

    let clamped = score.clamp(0, 100) as u8;
    let status = if recs.is_empty() {
        "ideal"
    } else if clamped >= 80 {
        "good"
    } else {
        "attention"
    };

    Ok(AnalysisReport {
        score: clamped,
        status: status.to_string(),
        recommendations: recs,
        checks,
        analyzed_at: Local::now().format("%H:%M:%S").to_string(),
    })
}
