use chrono::Local;
use serde::Serialize;
use std::io::Write;
use std::net::{SocketAddr, TcpStream, UdpSocket};
use std::os::windows::process::CommandExt;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

const CREATE_NO_WINDOW: u32 = 0x0800_0000;

#[derive(Serialize, Clone)]
pub struct PingHostResult {
    pub label: String,
    pub host: String,
    pub avg_ms: Option<f64>,
    pub min_ms: Option<f64>,
    pub max_ms: Option<f64>,
    pub jitter_ms: Option<f64>,
    pub loss_pct: f64,
}

#[derive(Serialize, Clone)]
pub struct NetInfoReport {
    pub local_ip: String,
    pub pings: Vec<PingHostResult>,
    pub checked_at: String,
}

#[derive(Serialize, Clone)]
pub struct SpeedTestReport {
    pub ping_ms: Option<f64>,
    pub jitter_ms: Option<f64>,
    pub download_mbps: Option<f64>,
    pub upload_mbps: Option<f64>,
    pub public_ip: String,
    pub isp: String,
    pub country: String,
    pub server: String,
    pub tested_at: String,
}

pub fn get_local_ip() -> String {
    if let Ok(sock) = UdpSocket::bind("0.0.0.0:0") {
        if sock.connect("1.1.1.1:80").is_ok() {
            if let Ok(addr) = sock.local_addr() {
                return addr.ip().to_string();
            }
        }
    }
    "127.0.0.1".to_string()
}

pub fn ping_tcp_host(label: &str, addr_str: &str, samples: usize) -> PingHostResult {
    let Ok(addr) = addr_str.parse::<SocketAddr>() else {
        return PingHostResult {
            label: label.to_string(),
            host: addr_str.to_string(),
            avg_ms: None,
            min_ms: None,
            max_ms: None,
            jitter_ms: None,
            loss_pct: 100.0,
        };
    };

    let mut rtts = Vec::with_capacity(samples);
    for _ in 0..samples {
        let start = Instant::now();
        if TcpStream::connect_timeout(&addr, Duration::from_millis(1200)).is_ok() {
            let ms = start.elapsed().as_secs_f64() * 1000.0;
            rtts.push(ms);
        }
    }

    if rtts.is_empty() {
        return PingHostResult {
            label: label.to_string(),
            host: addr_str.to_string(),
            avg_ms: None,
            min_ms: None,
            max_ms: None,
            jitter_ms: None,
            loss_pct: 100.0,
        };
    }

    let sum: f64 = rtts.iter().sum();
    let avg = sum / rtts.len() as f64;
    let min = rtts.iter().cloned().fold(f64::INFINITY, f64::min);
    let max = rtts.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    let jitter = if rtts.len() > 1 {
        let diffs: f64 = rtts.windows(2).map(|w| (w[1] - w[0]).abs()).sum();
        Some(((diffs / (rtts.len() - 1) as f64) * 10.0).round() / 10.0)
    } else {
        Some(0.0)
    };
    let loss = ((samples - rtts.len()) as f64 / samples as f64) * 100.0;

    PingHostResult {
        label: label.to_string(),
        host: addr_str.to_string(),
        avg_ms: Some((avg * 10.0).round() / 10.0),
        min_ms: Some((min * 10.0).round() / 10.0),
        max_ms: Some((max * 10.0).round() / 10.0),
        jitter_ms: jitter,
        loss_pct: (loss * 10.0).round() / 10.0,
    }
}

pub fn collect_net_info() -> NetInfoReport {
    let hosts = [
        ("Cloudflare DNS", "1.1.1.1:443"),
        ("Google DNS", "8.8.8.8:443"),
        ("Yandex DNS", "77.88.8.8:443"),
    ];
    let pings = hosts
        .iter()
        .map(|(lbl, addr)| ping_tcp_host(lbl, addr, 4))
        .collect();

    NetInfoReport {
        local_ip: get_local_ip(),
        pings,
        checked_at: Local::now().format("%H:%M:%S").to_string(),
    }
}

pub fn run_speed_test() -> SpeedTestReport {
    let ping_res = ping_tcp_host("Cloudflare", "1.1.1.1:443", 5);

    // Download test (15 MB from Cloudflare Speed Test)
    let download_mbps = measure_download_mbps();

    // Upload test (3 MB to Cloudflare Speed Test)
    let upload_mbps = measure_upload_mbps();

    // Public IP & ISP lookup (best effort, short timeout)
    let (public_ip, isp, country) = fetch_public_ip_info();

    SpeedTestReport {
        ping_ms: ping_res.avg_ms,
        jitter_ms: ping_res.jitter_ms,
        download_mbps,
        upload_mbps,
        public_ip,
        isp,
        country,
        server: "Cloudflare Edge".to_string(),
        tested_at: Local::now().format("%H:%M:%S").to_string(),
    }
}

fn measure_download_mbps() -> Option<f64> {
    let out = Command::new("curl.exe")
        .args([
            "-s",
            "-o",
            "NUL",
            "--max-time",
            "10",
            "-H",
            "Referer: https://speed.cloudflare.com/",
            "-H",
            "User-Agent: Mozilla/5.0",
            "-w",
            "%{speed_download};%{http_code}",
            "https://speed.cloudflare.com/__down?bytes=10000000",
        ])
        .creation_flags(CREATE_NO_WINDOW)
        .output()
        .ok()?;
    if !out.status.success() {
        return None;
    }
    let txt = String::from_utf8_lossy(&out.stdout);
    let mut parts = txt.trim().split(';');
    let bps: f64 = parts.next()?.replace(',', ".").parse().ok()?;
    let code = parts.next().unwrap_or("0");
    if code != "200" || bps <= 0.0 {
        return None;
    }
    Some(((bps * 8.0 / 1_000_000.0) * 100.0).round() / 100.0)
}

fn measure_upload_mbps() -> Option<f64> {
    let mut child = Command::new("curl.exe")
        .args([
            "-s",
            "-o",
            "NUL",
            "--max-time",
            "10",
            "-H",
            "Referer: https://speed.cloudflare.com/",
            "-H",
            "User-Agent: Mozilla/5.0",
            "-X",
            "POST",
            "--data-binary",
            "@-",
            "-w",
            "%{speed_upload};%{http_code}",
            "https://speed.cloudflare.com/__up",
        ])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .creation_flags(CREATE_NO_WINDOW)
        .spawn()
        .ok()?;

    if let Some(mut stdin) = child.stdin.take() {
        let chunk = vec![0u8; 64 * 1024];
        // 3 MB upload payload
        for _ in 0..48 {
            if stdin.write_all(&chunk).is_err() {
                break;
            }
        }
    }

    let out = child.wait_with_output().ok()?;
    if !out.status.success() {
        return None;
    }
    let txt = String::from_utf8_lossy(&out.stdout);
    let mut parts = txt.trim().split(';');
    let bps: f64 = parts.next()?.replace(',', ".").parse().ok()?;
    let code = parts.next().unwrap_or("0");
    if code != "200" || bps <= 0.0 {
        return None;
    }
    Some(((bps * 8.0 / 1_000_000.0) * 100.0).round() / 100.0)
}

fn fetch_public_ip_info() -> (String, String, String) {
    let out = Command::new("curl.exe")
        .args(["-s", "--max-time", "2", "https://ipinfo.io/json"])
        .creation_flags(CREATE_NO_WINDOW)
        .output();
    let Ok(res) = out else {
        return (String::new(), String::new(), String::new());
    };
    if !res.status.success() {
        return (String::new(), String::new(), String::new());
    }
    let Ok(val) = serde_json::from_slice::<serde_json::Value>(&res.stdout) else {
        return (String::new(), String::new(), String::new());
    };
    let ip = val.get("ip").and_then(|v| v.as_str()).unwrap_or("").to_string();
    let org = val.get("org").and_then(|v| v.as_str()).unwrap_or("").to_string();
    let country = val.get("country").and_then(|v| v.as_str()).unwrap_or("").to_string();
    (ip, org, country)
}
