use chrono::{Local, NaiveDate};
use serde::Serialize;
use std::collections::{HashMap, HashSet};
use std::os::windows::process::CommandExt;
use std::process::Command;
use std::sync::Mutex;
use std::time::Instant;
use sysinfo::{
    CpuRefreshKind, Disks, MemoryRefreshKind, Networks, ProcessRefreshKind, ProcessesToUpdate,
    RefreshKind, System,
};
use windows::core::PCWSTR;
use windows::Win32::Graphics::Gdi::{
    EnumDisplayDevicesW, EnumDisplaySettingsW, DEVMODEW, DISPLAY_DEVICEW, ENUM_CURRENT_SETTINGS,
};
use wmi::{COMLibrary, Variant, WMIConnection};

const CREATE_NO_WINDOW: u32 = 0x0800_0000;

#[derive(Serialize, Clone, Default)]
pub struct SystemSummary {
    pub hostname: String,
    pub manufacturer: String,
    pub model: String,
    pub total_ram_bytes: u64,
    pub domain: String,
}

#[derive(Serialize, Clone, Default)]
pub struct OsInfo {
    pub caption: String,
    pub version: String,
    pub build: String,
    pub architecture: String,
    pub serial_number: String,
    pub last_boot: String,
}

#[derive(Serialize, Clone, Default)]
pub struct MotherboardInfo {
    pub manufacturer: String,
    pub product: String,
    pub version: String,
    pub serial_number: String,
}

#[derive(Serialize, Clone, Default)]
pub struct BiosInfo {
    pub manufacturer: String,
    pub version: String,
    pub serial_number: String,
    pub release_date: String,
}

#[derive(Serialize, Clone, Default)]
pub struct CpuInfo {
    pub name: String,
    pub manufacturer: String,
    pub cores: u64,
    pub logical_processors: u64,
    pub max_clock_mhz: u64,
    pub socket: String,
    pub processor_id: String,
    pub serial_number: String,
    pub l2_cache_kb: u64,
    pub l3_cache_kb: u64,
}

#[derive(Serialize, Clone, Default)]
pub struct RamModuleInfo {
    pub slot: String,
    pub bank: String,
    pub manufacturer: String,
    pub part_number: String,
    pub serial_number: String,
    pub capacity_bytes: u64,
    pub speed_mhz: u64,
    pub configured_speed_mhz: u64,
}

#[derive(Serialize, Clone, Default)]
pub struct DiskDriveInfo {
    pub model: String,
    pub serial_number: String,
    pub interface_type: String,
    pub media_type: String,
    pub size_bytes: u64,
    pub firmware_revision: String,
    pub partitions: u64,
    pub device_id: String,
    pub pnp_device_id: String,
}

#[derive(Serialize, Clone, Default)]
pub struct GpuInfo {
    pub name: String,
    pub adapter_compatibility: String,
    pub driver_version: String,
    pub driver_date: String,
    pub video_processor: String,
    pub adapter_ram_bytes: u64,
    pub pnp_device_id: String,
    pub resolution: String,
    pub refresh_rate_hz: u64,
    pub status: String,
    pub nvidia_uuid: String,
    pub serial_number: String,
    pub vbios_version: String,
    pub pci_bus_id: String,
    pub vram_mb: u64,
}

#[derive(Serialize, Clone, Default)]
pub struct NetworkAdapterInfo {
    pub name: String,
    pub adapter_type: String,
    pub manufacturer: String,
    pub mac_address: String,
    pub speed_bps: u64,
    pub connection_id: String,
    pub status_code: u64,
    pub pnp_device_id: String,
    pub physical: bool,
}

#[derive(Serialize, Clone, Default)]
pub struct MonitorInfo {
    pub manufacturer: String,
    pub name: String,
    pub product_code: String,
    pub serial_number: String,
    pub year_of_manufacture: u64,
    pub week_of_manufacture: u64,
    pub instance_name: String,
    pub device_name: String,
    pub display_adapter: String,
    pub current_resolution: String,
    pub max_resolution: String,
    pub current_hz: u64,
    pub max_hz: u64,
}

#[derive(Serialize, Clone, Default)]
pub struct HardwareInventory {
    pub system: SystemSummary,
    pub os: OsInfo,
    pub motherboard: MotherboardInfo,
    pub bios: BiosInfo,
    pub cpus: Vec<CpuInfo>,
    pub ram_modules: Vec<RamModuleInfo>,
    pub disks: Vec<DiskDriveInfo>,
    pub gpus: Vec<GpuInfo>,
    pub network_adapters: Vec<NetworkAdapterInfo>,
    pub monitors: Vec<MonitorInfo>,
    pub collected_at: String,
    pub platform_node: String,
}

#[derive(Serialize, Clone)]
pub struct CpuLive {
    pub percent: f64,
    pub per_core: Vec<f32>,
    pub freq_current_mhz: Option<u64>,
    pub freq_max_mhz: Option<u64>,
    pub process_count: usize,
}

#[derive(Serialize, Clone)]
pub struct MemoryLive {
    pub total_bytes: u64,
    pub used_bytes: u64,
    pub available_bytes: u64,
    pub percent: f64,
    pub swap_total_bytes: u64,
    pub swap_used_bytes: u64,
    pub swap_percent: f64,
}

#[derive(Serialize, Clone)]
pub struct NetworkLive {
    pub rx_bytes_per_sec: f64,
    pub tx_bytes_per_sec: f64,
    pub total_rx_bytes: u64,
    pub total_tx_bytes: u64,
}

#[derive(Serialize, Clone)]
pub struct PartitionLive {
    pub device: String,
    pub mountpoint: String,
    pub fstype: String,
    pub total_bytes: u64,
    pub used_bytes: u64,
    pub free_bytes: u64,
    pub percent: f64,
}

#[derive(Serialize, Clone)]
pub struct DiskLive {
    pub read_bytes_per_sec: f64,
    pub write_bytes_per_sec: f64,
    pub partitions: Vec<PartitionLive>,
}

#[derive(Serialize, Clone)]
pub struct GpuLive {
    pub index: String,
    pub name: String,
    pub utilization_pct: Option<f64>,
    pub temperature_c: Option<f64>,
    pub memory_used_mb: Option<f64>,
    pub memory_total_mb: Option<f64>,
    pub power_draw_w: Option<f64>,
    pub clock_mhz: Option<f64>,
}

#[derive(Serialize, Clone)]
pub struct ProcessLive {
    pub pid: u32,
    pub name: String,
    pub cpu_percent: f64,
    pub memory_mb: f64,
}

#[derive(Serialize, Clone)]
pub struct LiveTelemetry {
    pub timestamp: String,
    pub uptime_seconds: u64,
    pub cpu: CpuLive,
    pub memory: MemoryLive,
    pub network: NetworkLive,
    pub disk: DiskLive,
    pub gpus_live: Vec<GpuLive>,
    pub top_processes: Vec<ProcessLive>,
}

struct NvidiaStatic {
    name: String,
    uuid: String,
    serial: String,
    vbios_version: String,
    memory_total_mb: u64,
    pci_bus_id: String,
}

struct DisplayModeInfo {
    device_name: String,
    display_adapter: String,
    current_resolution: String,
    max_resolution: String,
    current_hz: u64,
    max_hz: u64,
}

struct LiveState {
    sys: System,
    networks: Networks,
    disks: Disks,
    last_ts: Instant,
    has_nvidia: Option<bool>,
    last_gpu_ts: Instant,
    gpu_live_cache: Vec<GpuLive>,
    last_disks_refresh: Instant,
    last_cpu_pct: f64,
    last_mem_pct: f64,
}

pub struct HardwareCollector {
    hw_cache: Mutex<Option<HardwareInventory>>,
    live_state: Mutex<LiveState>,
}

impl HardwareCollector {
    pub fn new() -> Self {
        let mut sys = System::new_with_specifics(
            RefreshKind::nothing()
                .with_cpu(CpuRefreshKind::everything())
                .with_memory(MemoryRefreshKind::everything())
                .with_processes(ProcessRefreshKind::nothing().with_cpu().with_memory().with_disk_usage()),
        );
        sys.refresh_cpu_all();
        sys.refresh_memory();
        sys.refresh_processes(ProcessesToUpdate::All, true);

        let networks = Networks::new_with_refreshed_list();
        let disks = Disks::new_with_refreshed_list();
        let now = Instant::now();

        Self {
            hw_cache: Mutex::new(None),
            live_state: Mutex::new(LiveState {
                sys,
                networks,
                disks,
                last_ts: now,
                has_nvidia: None,
                last_gpu_ts: now - std::time::Duration::from_secs(5),
                gpu_live_cache: Vec::new(),
                last_disks_refresh: now,
                last_cpu_pct: 0.0,
                last_mem_pct: 0.0,
            }),
        }
    }

    pub fn get_tray_snapshot(&self) -> (f64, f64, Option<f64>) {
        let Ok(mut state) = self.live_state.lock() else {
            return (0.0, 0.0, None);
        };
        let now = Instant::now();
        if now.duration_since(state.last_ts).as_secs_f64() >= 2.8 {
            state.sys.refresh_cpu_usage();
            state.sys.refresh_memory();
            let per_core: Vec<f32> = state.sys.cpus().iter().map(|c| c.cpu_usage()).collect();
            if !per_core.is_empty() {
                let sum: f64 = per_core.iter().map(|&v| v as f64).sum();
                state.last_cpu_pct = ((sum / per_core.len() as f64) * 10.0).round() / 10.0;
            }
            let total = state.sys.total_memory();
            let used = total.saturating_sub(state.sys.available_memory());
            if total > 0 {
                state.last_mem_pct = ((used as f64 / total as f64) * 1000.0).round() / 10.0;
            }
            if state.has_nvidia != Some(false) && now.duration_since(state.last_gpu_ts).as_secs_f64() >= 2.5 {
                let gpus = Self::query_nvidia_smi_live();
                if gpus.is_empty() && state.has_nvidia.is_none() {
                    state.has_nvidia = Some(false);
                } else if !gpus.is_empty() {
                    state.has_nvidia = Some(true);
                }
                state.gpu_live_cache = gpus;
                state.last_gpu_ts = now;
            }
            state.last_ts = now;
        }
        let gpu_temp = state.gpu_live_cache.first().and_then(|g| g.temperature_c);
        (state.last_cpu_pct, state.last_mem_pct, gpu_temp)
    }

    pub fn get_hardware_inventory(&self, force_refresh: bool) -> Result<HardwareInventory, String> {
        {
            let guard = self.hw_cache.lock().map_err(|e| e.to_string())?;
            if !force_refresh {
                if let Some(ref cached) = *guard {
                    return Ok(cached.clone());
                }
            }
        }

        let inv = Self::collect_hardware_inventory()?;
        let mut guard = self.hw_cache.lock().map_err(|e| e.to_string())?;
        *guard = Some(inv.clone());
        Ok(inv)
    }

    pub fn get_live_telemetry(&self) -> Result<LiveTelemetry, String> {
        let mut state = self.live_state.lock().map_err(|e| e.to_string())?;
        let now = Instant::now();
        let dt = now.duration_since(state.last_ts).as_secs_f64().max(0.1);
        state.last_ts = now;

        state.sys.refresh_cpu_usage();
        state.sys.refresh_memory();
        state.sys.refresh_processes(ProcessesToUpdate::All, true);
        state.networks.refresh(true);

        if now.duration_since(state.last_disks_refresh).as_secs_f64() >= 15.0 {
            state.disks.refresh(true);
            state.last_disks_refresh = now;
        } else {
            state.disks.refresh(false);
        }

        // CPU
        let per_core: Vec<f32> = state
            .sys
            .cpus()
            .iter()
            .map(|c| (c.cpu_usage() * 10.0).round() / 10.0)
            .collect();
        let cpu_total = if per_core.is_empty() {
            0.0
        } else {
            let sum: f64 = per_core.iter().map(|&v| v as f64).sum();
            ((sum / per_core.len() as f64) * 10.0).round() / 10.0
        };
        let freq_current_mhz = state.sys.cpus().first().map(|c| c.frequency());

        // Memory
        let total_mem = state.sys.total_memory();
        let avail_mem = state.sys.available_memory();
        let used_mem = total_mem.saturating_sub(avail_mem);
        let mem_pct = if total_mem > 0 {
            ((used_mem as f64 / total_mem as f64) * 1000.0).round() / 10.0
        } else {
            0.0
        };

        let swap_total = state.sys.total_swap();
        let swap_used = state.sys.used_swap();
        let swap_pct = if swap_total > 0 {
            ((swap_used as f64 / swap_total as f64) * 1000.0).round() / 10.0
        } else {
            0.0
        };

        // Network IO
        let mut rx_delta = 0u64;
        let mut tx_delta = 0u64;
        let mut total_rx = 0u64;
        let mut total_tx = 0u64;
        for (_name, data) in &state.networks {
            rx_delta += data.received();
            tx_delta += data.transmitted();
            total_rx += data.total_received();
            total_tx += data.total_transmitted();
        }
        let net_rx_bps = ((rx_delta as f64 / dt) * 10.0).round() / 10.0;
        let net_tx_bps = ((tx_delta as f64 / dt) * 10.0).round() / 10.0;

        // Disk IO (from process disk usage deltas) + Partitions
        let mut disk_read_delta = 0u64;
        let mut disk_write_delta = 0u64;
        let mut procs: Vec<ProcessLive> = Vec::new();
        let total_procs = state.sys.processes().len();
        let core_count = per_core.len().max(1) as f64;

        for (pid, proc_item) in state.sys.processes() {
            let du = proc_item.disk_usage();
            disk_read_delta += du.read_bytes;
            disk_write_delta += du.written_bytes;

            let pid_u32 = pid.as_u32();
            if pid_u32 == 0 {
                continue;
            }
            let cpu_p = ((((proc_item.cpu_usage() as f64) / core_count).min(100.0)) * 10.0).round() / 10.0;
            let mem_mb = ((proc_item.memory() as f64 / (1024.0 * 1024.0)) * 10.0).round() / 10.0;
            procs.push(ProcessLive {
                pid: pid_u32,
                name: proc_item.name().to_string_lossy().to_string(),
                cpu_percent: cpu_p,
                memory_mb: mem_mb,
            });
        }

        procs.sort_by(|a, b| {
            b.cpu_percent
                .partial_cmp(&a.cpu_percent)
                .unwrap_or(std::cmp::Ordering::Equal)
                .then_with(|| {
                    b.memory_mb
                        .partial_cmp(&a.memory_mb)
                        .unwrap_or(std::cmp::Ordering::Equal)
                })
        });
        procs.truncate(8);

        let mut partitions = Vec::new();
        let mut seen_mounts = HashSet::new();
        for d in &state.disks {
            let mount = d.mount_point().to_string_lossy().to_string();
            if mount.is_empty() || !seen_mounts.insert(mount.clone()) {
                continue;
            }
            let total = d.total_space();
            if total == 0 {
                continue;
            }
            let free = d.available_space();
            let used = total.saturating_sub(free);
            let pct = ((used as f64 / total as f64) * 1000.0).round() / 10.0;
            partitions.push(PartitionLive {
                device: d.name().to_string_lossy().to_string(),
                mountpoint: mount,
                fstype: d.file_system().to_string_lossy().to_string(),
                total_bytes: total,
                used_bytes: used,
                free_bytes: free,
                percent: pct,
            });
        }

        // Throttled nvidia-smi live query
        if state.has_nvidia != Some(false) && now.duration_since(state.last_gpu_ts).as_secs_f64() >= 1.8 {
            let gpus = Self::query_nvidia_smi_live();
            if gpus.is_empty() && state.has_nvidia.is_none() {
                state.has_nvidia = Some(false);
            } else if !gpus.is_empty() {
                state.has_nvidia = Some(true);
            }
            state.gpu_live_cache = gpus;
            state.last_gpu_ts = now;
        }

        state.last_cpu_pct = cpu_total;
        state.last_mem_pct = mem_pct;

        Ok(LiveTelemetry {
            timestamp: Local::now().format("%H:%M:%S").to_string(),
            uptime_seconds: System::uptime(),
            cpu: CpuLive {
                percent: cpu_total,
                per_core,
                freq_current_mhz,
                freq_max_mhz: freq_current_mhz,
                process_count: total_procs,
            },
            memory: MemoryLive {
                total_bytes: total_mem,
                used_bytes: used_mem,
                available_bytes: avail_mem,
                percent: mem_pct,
                swap_total_bytes: swap_total,
                swap_used_bytes: swap_used,
                swap_percent: swap_pct,
            },
            network: NetworkLive {
                rx_bytes_per_sec: net_rx_bps,
                tx_bytes_per_sec: net_tx_bps,
                total_rx_bytes: total_rx,
                total_tx_bytes: total_tx,
            },
            disk: DiskLive {
                read_bytes_per_sec: ((disk_read_delta as f64 / dt) * 10.0).round() / 10.0,
                write_bytes_per_sec: ((disk_write_delta as f64 / dt) * 10.0).round() / 10.0,
                partitions,
            },
            gpus_live: state.gpu_live_cache.clone(),
            top_processes: procs,
        })
    }

    fn collect_hardware_inventory() -> Result<HardwareInventory, String> {
        let com = COMLibrary::new().map_err(|e| format!("COM init failed: {e}"))?;
        let cim = WMIConnection::new(com).map_err(|e| format!("WMI cimv2 failed: {e}"))?;

        let mut inv = HardwareInventory {
            collected_at: Local::now().format("%Y-%m-%d %H:%M:%S").to_string(),
            platform_node: System::host_name().unwrap_or_else(|| "PC".to_string()),
            ..Default::default()
        };

        // ComputerSystem
        if let Ok(rows) = query_wmi(&cim, "SELECT Manufacturer, Model, TotalPhysicalMemory, Name, Domain FROM Win32_ComputerSystem") {
            if let Some(r) = rows.first() {
                inv.system = SystemSummary {
                    hostname: get_str(r, "Name"),
                    manufacturer: get_str(r, "Manufacturer"),
                    model: get_str(r, "Model"),
                    total_ram_bytes: get_u64(r, "TotalPhysicalMemory"),
                    domain: get_str(r, "Domain"),
                };
            }
        }

        // BaseBoard
        if let Ok(rows) = query_wmi(&cim, "SELECT Manufacturer, Product, SerialNumber, Version FROM Win32_BaseBoard") {
            if let Some(r) = rows.first() {
                inv.motherboard = MotherboardInfo {
                    manufacturer: get_str(r, "Manufacturer"),
                    product: get_str(r, "Product"),
                    version: get_str(r, "Version"),
                    serial_number: get_str(r, "SerialNumber"),
                };
            }
        }

        // BIOS
        if let Ok(rows) = query_wmi(&cim, "SELECT Manufacturer, SMBIOSBIOSVersion, SerialNumber, ReleaseDate FROM Win32_BIOS") {
            if let Some(r) = rows.first() {
                inv.bios = BiosInfo {
                    manufacturer: get_str(r, "Manufacturer"),
                    version: get_str(r, "SMBIOSBIOSVersion"),
                    serial_number: get_str(r, "SerialNumber"),
                    release_date: format_wmi_date(&get_str(r, "ReleaseDate"), false),
                };
            }
        }

        // OperatingSystem
        if let Ok(rows) = query_wmi(&cim, "SELECT Caption, Version, BuildNumber, SerialNumber, OSArchitecture, LastBootUpTime FROM Win32_OperatingSystem") {
            if let Some(r) = rows.first() {
                inv.os = OsInfo {
                    caption: get_str(r, "Caption"),
                    version: get_str(r, "Version"),
                    build: get_str(r, "BuildNumber"),
                    architecture: get_str(r, "OSArchitecture"),
                    serial_number: get_str(r, "SerialNumber"),
                    last_boot: format_wmi_date(&get_str(r, "LastBootUpTime"), true),
                };
            }
        }

        // CPUs
        if let Ok(rows) = query_wmi(&cim, "SELECT Name, Manufacturer, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed, SocketDesignation, ProcessorId, SerialNumber, L2CacheSize, L3CacheSize FROM Win32_Processor") {
            for r in rows {
                inv.cpus.push(CpuInfo {
                    name: get_str(&r, "Name"),
                    manufacturer: get_str(&r, "Manufacturer"),
                    cores: get_u64(&r, "NumberOfCores"),
                    logical_processors: get_u64(&r, "NumberOfLogicalProcessors"),
                    max_clock_mhz: get_u64(&r, "MaxClockSpeed"),
                    socket: get_str(&r, "SocketDesignation"),
                    processor_id: get_str(&r, "ProcessorId"),
                    serial_number: get_str(&r, "SerialNumber"),
                    l2_cache_kb: get_u64(&r, "L2CacheSize"),
                    l3_cache_kb: get_u64(&r, "L3CacheSize"),
                });
            }
        }

        // RAM modules
        if let Ok(rows) = query_wmi(&cim, "SELECT DeviceLocator, BankLabel, Manufacturer, PartNumber, SerialNumber, Capacity, Speed, ConfiguredClockSpeed FROM Win32_PhysicalMemory") {
            for r in rows {
                inv.ram_modules.push(RamModuleInfo {
                    slot: get_str(&r, "DeviceLocator"),
                    bank: get_str(&r, "BankLabel"),
                    manufacturer: get_str(&r, "Manufacturer"),
                    part_number: get_str(&r, "PartNumber"),
                    serial_number: get_str(&r, "SerialNumber"),
                    capacity_bytes: get_u64(&r, "Capacity"),
                    speed_mhz: get_u64(&r, "Speed"),
                    configured_speed_mhz: get_u64(&r, "ConfiguredClockSpeed"),
                });
            }
        }

        // Disks
        if let Ok(rows) = query_wmi(&cim, "SELECT Model, SerialNumber, InterfaceType, MediaType, Size, FirmwareRevision, Partitions, DeviceID, PNPDeviceID FROM Win32_DiskDrive") {
            for r in rows {
                inv.disks.push(DiskDriveInfo {
                    model: get_str(&r, "Model"),
                    serial_number: get_str(&r, "SerialNumber"),
                    interface_type: get_str(&r, "InterfaceType"),
                    media_type: get_str(&r, "MediaType"),
                    size_bytes: get_u64(&r, "Size"),
                    firmware_revision: get_str(&r, "FirmwareRevision"),
                    partitions: get_u64(&r, "Partitions"),
                    device_id: get_str(&r, "DeviceID"),
                    pnp_device_id: get_str(&r, "PNPDeviceID"),
                });
            }
        }

        // GPUs
        let nv_static = Self::query_nvidia_smi_static();
        if let Ok(rows) = query_wmi(&cim, "SELECT Name, AdapterCompatibility, DriverVersion, DriverDate, VideoProcessor, AdapterRAM, PNPDeviceID, CurrentHorizontalResolution, CurrentVerticalResolution, CurrentRefreshRate, Status FROM Win32_VideoController") {
            for r in rows {
                let hw = get_u64(&r, "CurrentHorizontalResolution");
                let vw = get_u64(&r, "CurrentVerticalResolution");
                let mut gpu = GpuInfo {
                    name: get_str(&r, "Name"),
                    adapter_compatibility: get_str(&r, "AdapterCompatibility"),
                    driver_version: get_str(&r, "DriverVersion"),
                    driver_date: format_wmi_date(&get_str(&r, "DriverDate"), false),
                    video_processor: get_str(&r, "VideoProcessor"),
                    adapter_ram_bytes: get_u64(&r, "AdapterRAM"),
                    pnp_device_id: get_str(&r, "PNPDeviceID"),
                    resolution: if hw > 0 && vw > 0 { format!("{hw}x{vw}") } else { String::new() },
                    refresh_rate_hz: get_u64(&r, "CurrentRefreshRate"),
                    status: get_str(&r, "Status"),
                    ..Default::default()
                };
                let g_low = gpu.name.to_lowercase();
                for nv in &nv_static {
                    let nv_low = nv.name.to_lowercase();
                    if nv_low.contains(&g_low) || g_low.contains(&nv_low) {
                        gpu.nvidia_uuid = nv.uuid.clone();
                        if !nv.serial.is_empty() {
                            gpu.serial_number = nv.serial.clone();
                        }
                        gpu.vbios_version = nv.vbios_version.clone();
                        gpu.pci_bus_id = nv.pci_bus_id.clone();
                        if nv.memory_total_mb > 0 {
                            gpu.vram_mb = nv.memory_total_mb;
                        }
                    }
                }
                inv.gpus.push(gpu);
            }
        }

        // Network Adapters
        if let Ok(rows) = query_wmi(&cim, "SELECT Name, AdapterType, Manufacturer, MACAddress, Speed, NetConnectionID, NetConnectionStatus, PNPDeviceID, PhysicalAdapter FROM Win32_NetworkAdapter") {
            for r in rows {
                let physical = get_bool(&r, "PhysicalAdapter");
                let mac = get_str(&r, "MACAddress");
                if !physical && mac.is_empty() {
                    continue;
                }
                inv.network_adapters.push(NetworkAdapterInfo {
                    name: get_str(&r, "Name"),
                    adapter_type: get_str(&r, "AdapterType"),
                    manufacturer: get_str(&r, "Manufacturer"),
                    mac_address: mac,
                    speed_bps: get_u64(&r, "Speed"),
                    connection_id: get_str(&r, "NetConnectionID"),
                    status_code: get_u64(&r, "NetConnectionStatus"),
                    pnp_device_id: get_str(&r, "PNPDeviceID"),
                    physical,
                });
            }
        }

        // Monitors (root\wmi + Win32 EnumDisplaySettingsW)
        if let Ok(wmi_mon) = WMIConnection::with_namespace_path("root\\wmi", com) {
            if let Ok(rows) = query_wmi(&wmi_mon, "SELECT ManufacturerName, UserFriendlyName, ProductCodeID, SerialNumberID, YearOfManufacture, WeekOfManufacture, InstanceName FROM WmiMonitorID") {
                for r in rows {
                    inv.monitors.push(MonitorInfo {
                        manufacturer: decode_wmi_bytes(&r, "ManufacturerName"),
                        name: decode_wmi_bytes(&r, "UserFriendlyName"),
                        product_code: decode_wmi_bytes(&r, "ProductCodeID"),
                        serial_number: decode_wmi_bytes(&r, "SerialNumberID"),
                        year_of_manufacture: get_u64(&r, "YearOfManufacture"),
                        week_of_manufacture: get_u64(&r, "WeekOfManufacture"),
                        instance_name: get_str(&r, "InstanceName"),
                        ..Default::default()
                    });
                }
            }
        }

        let display_modes = Self::query_display_modes();
        for (idx, mon) in inv.monitors.iter_mut().enumerate() {
            if let Some(dm) = display_modes.get(idx) {
                mon.device_name = dm.device_name.clone();
                mon.display_adapter = dm.display_adapter.clone();
                mon.current_resolution = dm.current_resolution.clone();
                mon.max_resolution = dm.max_resolution.clone();
                mon.current_hz = dm.current_hz;
                mon.max_hz = dm.max_hz;
            }
        }
        if display_modes.len() > inv.monitors.len() {
            for extra in &display_modes[inv.monitors.len()..] {
                inv.monitors.push(MonitorInfo {
                    name: extra.device_name.clone(),
                    device_name: extra.device_name.clone(),
                    display_adapter: extra.display_adapter.clone(),
                    current_resolution: extra.current_resolution.clone(),
                    max_resolution: extra.max_resolution.clone(),
                    current_hz: extra.current_hz,
                    max_hz: extra.max_hz,
                    ..Default::default()
                });
            }
        }

        Ok(inv)
    }

    fn query_display_modes() -> Vec<DisplayModeInfo> {
        let mut displays = Vec::new();
        let mut idx = 0u32;
        unsafe {
            loop {
                let mut dd = DISPLAY_DEVICEW::default();
                dd.cb = std::mem::size_of::<DISPLAY_DEVICEW>() as u32;
                if !EnumDisplayDevicesW(PCWSTR::null(), idx, &mut dd, 0).as_bool() {
                    break;
                }
                idx += 1;
                if (dd.StateFlags & 0x1) == 0 {
                    continue;
                }

                let mut dm = DEVMODEW::default();
                dm.dmSize = std::mem::size_of::<DEVMODEW>() as u16;
                if !EnumDisplaySettingsW(
                    PCWSTR(dd.DeviceName.as_ptr()),
                    ENUM_CURRENT_SETTINGS,
                    &mut dm,
                )
                .as_bool()
                {
                    continue;
                }

                let cur_w = dm.dmPelsWidth as u64;
                let cur_h = dm.dmPelsHeight as u64;
                let cur_hz = dm.dmDisplayFrequency as u64;
                let mut max_w = cur_w;
                let mut max_h = cur_h;
                let mut max_hz = cur_hz;

                let mut mode_idx = 0u32;
                while EnumDisplaySettingsW(
                    PCWSTR(dd.DeviceName.as_ptr()),
                    windows::Win32::Graphics::Gdi::ENUM_DISPLAY_SETTINGS_MODE(mode_idx),
                    &mut dm,
                )
                .as_bool()
                {
                    let w = dm.dmPelsWidth as u64;
                    let h = dm.dmPelsHeight as u64;
                    let hz = dm.dmDisplayFrequency as u64;
                    if w * h > max_w * max_h {
                        max_w = w;
                        max_h = h;
                    }
                    if hz > max_hz {
                        max_hz = hz;
                    }
                    mode_idx += 1;
                }

                displays.push(DisplayModeInfo {
                    device_name: utf16_to_string(&dd.DeviceName),
                    display_adapter: utf16_to_string(&dd.DeviceString),
                    current_resolution: format!("{cur_w}x{cur_h}"),
                    max_resolution: format!("{max_w}x{max_h}"),
                    current_hz: cur_hz,
                    max_hz,
                });
            }
        }
        displays
    }

    fn query_nvidia_smi_static() -> Vec<NvidiaStatic> {
        let out = Command::new("nvidia-smi")
            .args([
                "--query-gpu=index,name,uuid,serial,vbios_version,memory.total,pci.bus_id",
                "--format=csv,noheader,nounits",
            ])
            .creation_flags(CREATE_NO_WINDOW)
            .output();
        let Ok(res) = out else { return Vec::new() };
        if !res.status.success() {
            return Vec::new();
        }
        let text = String::from_utf8_lossy(&res.stdout);
        let mut items = Vec::new();
        for line in text.lines() {
            let parts: Vec<&str> = line.split(',').map(|s| s.trim()).collect();
            if parts.len() >= 7 {
                let serial = if parts[3] == "[N/A]" || parts[3] == "N/A" {
                    String::new()
                } else {
                    parts[3].to_string()
                };
                items.push(NvidiaStatic {
                    name: parts[1].to_string(),
                    uuid: parts[2].to_string(),
                    serial,
                    vbios_version: parts[4].to_string(),
                    memory_total_mb: parts[5].parse::<f64>().unwrap_or(0.0) as u64,
                    pci_bus_id: parts[6].to_string(),
                });
            }
        }
        items
    }

    fn query_nvidia_smi_live() -> Vec<GpuLive> {
        let out = Command::new("nvidia-smi")
            .args([
                "--query-gpu=index,name,utilization.gpu,temperature.gpu,memory.used,memory.total,power.draw,clocks.gr",
                "--format=csv,noheader,nounits",
            ])
            .creation_flags(CREATE_NO_WINDOW)
            .output();
        let Ok(res) = out else { return Vec::new() };
        if !res.status.success() {
            return Vec::new();
        }
        let text = String::from_utf8_lossy(&res.stdout);
        let mut items = Vec::new();
        for line in text.lines() {
            let parts: Vec<&str> = line.split(',').map(|s| s.trim()).collect();
            if parts.len() >= 8 {
                items.push(GpuLive {
                    index: parts[0].to_string(),
                    name: parts[1].to_string(),
                    utilization_pct: parts[2].parse::<f64>().ok(),
                    temperature_c: parts[3].parse::<f64>().ok(),
                    memory_used_mb: parts[4].parse::<f64>().ok(),
                    memory_total_mb: parts[5].parse::<f64>().ok(),
                    power_draw_w: parts[6].parse::<f64>().ok(),
                    clock_mhz: parts[7].parse::<f64>().ok(),
                });
            }
        }
        items
    }
}

fn query_wmi(conn: &WMIConnection, sql: &str) -> Result<Vec<HashMap<String, Variant>>, String> {
    conn.raw_query(sql).map_err(|e| e.to_string())
}

fn get_str(map: &HashMap<String, Variant>, key: &str) -> String {
    match map.get(key) {
        Some(Variant::String(s)) => s.trim().to_string(),
        Some(Variant::I4(v)) => v.to_string(),
        Some(Variant::UI4(v)) => v.to_string(),
        Some(Variant::I8(v)) => v.to_string(),
        Some(Variant::UI8(v)) => v.to_string(),
        _ => String::new(),
    }
}

fn get_u64(map: &HashMap<String, Variant>, key: &str) -> u64 {
    match map.get(key) {
        Some(Variant::UI8(v)) => *v,
        Some(Variant::I8(v)) if *v >= 0 => *v as u64,
        Some(Variant::UI4(v)) => *v as u64,
        Some(Variant::I4(v)) if *v >= 0 => *v as u64,
        Some(Variant::UI2(v)) => *v as u64,
        Some(Variant::I2(v)) if *v >= 0 => *v as u64,
        Some(Variant::UI1(v)) => *v as u64,
        Some(Variant::I1(v)) if *v >= 0 => *v as u64,
        Some(Variant::String(s)) => s.trim().parse::<u64>().unwrap_or(0),
        _ => 0,
    }
}

fn get_bool(map: &HashMap<String, Variant>, key: &str) -> bool {
    matches!(map.get(key), Some(Variant::Bool(true)))
}

fn decode_wmi_bytes(map: &HashMap<String, Variant>, key: &str) -> String {
    let Some(Variant::Array(arr)) = map.get(key) else {
        return String::new();
    };
    let mut out = String::new();
    for item in arr {
        let code = match item {
            Variant::UI2(v) => *v as u32,
            Variant::I2(v) if *v > 0 => *v as u32,
            Variant::UI1(v) => *v as u32,
            Variant::I4(v) if *v > 0 => *v as u32,
            Variant::UI4(v) => *v,
            _ => 0,
        };
        if code > 0 {
            if let Some(ch) = char::from_u32(code) {
                out.push(ch);
            }
        }
    }
    out.trim().to_string()
}

fn format_wmi_date(raw: &str, with_time: bool) -> String {
    // WMI CIM_DATETIME format: yyyymmddHHMMSS.ffffff+UUU
    if raw.len() < 8 {
        return String::new();
    }
    let Ok(y) = raw[0..4].parse::<i32>() else { return String::new() };
    let Ok(m) = raw[4..6].parse::<u32>() else { return String::new() };
    let Ok(d) = raw[6..8].parse::<u32>() else { return String::new() };
    if NaiveDate::from_ymd_opt(y, m, d).is_none() {
        return String::new();
    }
    if with_time && raw.len() >= 14 {
        let hh = &raw[8..10];
        let mm = &raw[10..12];
        let ss = &raw[12..14];
        format!("{y:04}-{m:02}-{d:02} {hh}:{mm}:{ss}")
    } else {
        format!("{y:04}-{m:02}-{d:02}")
    }
}

fn utf16_to_string(slice: &[u16]) -> String {
    let len = slice.iter().position(|&c| c == 0).unwrap_or(slice.len());
    String::from_utf16_lossy(&slice[..len]).trim().to_string()
}
