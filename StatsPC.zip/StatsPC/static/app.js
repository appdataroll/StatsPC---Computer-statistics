(() => {
  'use strict';

  const MAX_HISTORY = 40;
  const history = {
    cpu: [],
    ram: [],
    gpu: [],
  };

  let hardwareData = null;
  let lastLiveData = null;
  let liveTimerId = null;

  const SETTINGS_KEY = 'statspc_settings_v2';
  const DEFAULT_SETTINGS = {
    primary: '#34D399',
    secondary: '#38BDF8',
    themeMode: 'dark',
    intervalMs: 1000,
    glow: 55,
    zoom: 100,
    lang: 'en',
    showSerials: false,
    autostart: false,
    startMinimized: false,
    alertsEnabled: true,
    alertGpuTemp: 82,
    alertCpuPct: 90,
    alertRamPct: 90,
    diskMinGb: 1,
  };

  const I18N = {
    en: {
      pageTitle: 'StatsPC — PC Monitor & Hardware Specs',
      tabStats: 'Statistics',
      tabInternet: 'Internet',
      tabAnalysis: 'Analysis',
      tabSettings: 'Settings',
      analysisTitle: 'PC & Hardware Analysis',
      analysisDesc: 'Inspects components, drivers, temperatures, display refresh rate, and internet connection',
      runAnalysisBtn: 'Run Analysis',
      analyzingText: 'Phase 1/2: Analyzing hardware, drivers & temperatures...',
      analyzingInternetText: 'Phase 2/2: Analyzing internet speed, ping & packet loss...',
      heavyStorageBtn: 'Games & Folders',
      heavyAppsTitle: 'Heaviest Games & Apps',
      heavyFoldersTitle: 'Largest Folders on Drives',
      minSizeFilterLabel: 'Minimum size filter (1 GB – 1 TB)',
      gameKind: 'Game',
      appKind: 'App',
      analysisReadyTitle: 'Ready to analyze your PC',
      analysisReadySub: 'Click "Run Analysis" to check all components and receive recommendations',
      analysisIdealTitle: 'No recommendations — everything works ideally!',
      analysisIdealSub: 'All checked subsystems (drives, memory, CPU, GPU, display) are in optimal shape.',
      analysisFoundTitle: 'Analysis complete — recommendations found',
      analysisFoundSub: 'Checked at',
      analysisDoneToast: 'PC analysis completed',
      sevCritical: 'Critical',
      sevWarning: 'Warning',
      sevTip: 'Tip',
      sevOk: 'Ideal',
      netPageTitle: 'Internet & Speed Test',
      netPageDesc: 'Measure download/upload speed, latency, jitter, and DNS reachability',
      pingCheckBtn: 'Check Ping',
      runSpeedTestBtn: 'Start Speed Test',
      testingSpeedBtn: 'Testing...',
      speedDownLabel: 'Download',
      speedUpLabel: 'Upload',
      speedPingLabel: 'Ping / Jitter',
      ispLabel: 'Connection & ISP',
      dnsPingTitle: 'Server Latency (TCP Ping)',
      thServer: 'Server',
      thAvg: 'Avg',
      thLoss: 'Loss',
      clickPingHint: 'Click "Check Ping" to measure latency',
      startupAlertsTitle: 'Startup & Overheat Alerts',
      startupAlertsHint: 'Background & Thresholds',
      autostartTitle: 'Run at Windows Startup',
      autostartSub: 'Launch StatsPC automatically when Windows starts',
      startMinTitle: 'Start Minimized to Tray',
      startMinSub: 'Hide window into the system tray on startup',
      alertsToggleTitle: 'Overheat & High-Load Alerts',
      alertsToggleSub: 'Show warning when CPU, RAM, or GPU temperature exceeds limit',
      thresholdsTitle: 'Alert Thresholds',
      thresholdsSub: 'Trigger warning above these limits',
      onLabel: 'On',
      offLabel: 'Off',
      alertHighCpu: 'High CPU load',
      alertHighRam: 'High RAM usage',
      alertHighGpuTemp: 'GPU overheat',
      speedDoneToast: 'Speed test completed',
      shuttingDownTitle: 'Shutting down...',
      shuttingDownSub: 'See you next time',
      speedPhaseConnecting: 'Connecting to test server & measuring ping...',
      speedPhaseDownloading: 'Measuring download & upload throughput...',
      uptimeLabel: 'Uptime',
      allSerialsBtn: 'All Serials',
      refreshBtn: 'Refresh',
      refreshingBtn: 'Refreshing...',
      exportBtn: 'Export JSON',
      exitBtn: 'Exit',
      liveTitle: 'Current PC State',
      liveDesc: 'Real-time telemetry • updated every',
      cpuLabel: 'Processor (CPU)',
      ramLabel: 'Memory (RAM)',
      gpuLabel: 'Graphics (GPU)',
      ioLabel: 'Network & Disk I/O',
      ioBadge: 'Activity',
      netInLabel: 'Net Down (↓)',
      netOutLabel: 'Net Up (↑)',
      diskReadLabel: 'Disk Read',
      diskWriteLabel: 'Disk Write',
      drivesTitle: 'Logical Drives',
      drivesHint: 'Free space',
      procsTitle: 'Active Processes (Top 8)',
      procsHint: 'By CPU / RAM load',
      thProc: 'Process',
      hwTitle: 'PC Components',
      hwDesc: 'Click "Details" on any component to view full specifications and serial numbers',
      settingsTitle: 'Settings & Personalization',
      settingsDesc: 'Customize Liquid Glass colors, language, and telemetry refresh rate — changes apply immediately',
      resetBtn: 'Reset to Default',
      paletteTitle: 'Accent Palette',
      paletteHint: 'Custom colors',
      themeModeTitle: 'Theme Mode',
      themeModeSub: 'Switch between Dark and Light Liquid Glass',
      themeDark: 'Dark',
      themeLight: 'Light',
      primaryColorTitle: 'Primary Color (Accent)',
      primaryColorSub: 'Action buttons, LIVE badge, GPU, serial numbers',
      secondaryColorTitle: 'Secondary Color',
      secondaryColorSub: 'CPU chart, component icons, "Details" buttons, network',
      presetsTitle: 'Theme Presets',
      presetsHint: 'One click',
      effectsTitle: 'Language, Scale & Telemetry',
      effectsHint: 'Requires Save',
      unsavedChangesText: 'You have unsaved changes (scale, language, or refresh rate)',
      saveBtn: 'Save Changes',
      discardBtn: 'Cancel',
      savedToast: 'Settings saved & applied',
      discardedToast: 'Changes discarded',
      closeModalEyebrow: 'StatsPC',
      closeModalTitle: 'Close Application?',
      closeModalDesc: 'Minimize to the system tray to keep StatsPC running in the background, or exit completely?',
      minimizeTrayBtn: 'Minimize to Tray',
      exitCompleteBtn: 'Exit Completely',
      langTitle: 'Language / Язык',
      langSub: 'Interface language (default: English)',
      intervalTitle: 'Telemetry Refresh Rate',
      intervalSub: 'How often CPU, RAM, GPU, and network sensors are polled',
      glowTitle: 'Background Glow Intensity',
      glowSub: 'Brightness of ambient spheres behind the glass panels',
      zoomTitle: 'Interface Scale',
      zoomSub: 'Zoom in or out to fit your screen comfortably',
      heavyAppsTitle: 'Heaviest Installed Apps',
      heavyFoldersTitle: 'Largest Folders on Drives',
      scanningDisk: 'Scanning drives and installed apps...',
      rescanBtn: 'Rescan',
      noHeavyItems: 'No large items found',
      detailsBtn: 'Details',
      copyBtn: 'Copy',
      copiedToast: 'Copied',
      hwRefreshedToast: 'Hardware configuration refreshed',
      hwRefreshFailToast: 'Failed to refresh hardware data',
      hwLoadError: 'Error reading hardware data.',
      shutdownToast: 'StatsPC stopped',
      resetToast: 'Settings reset to default',
      themeApplied: 'Theme applied',
      langToast: 'Language: English',
      serialsTitle: 'Serial Numbers & Identifiers',
      serialsOff: 'Serials: Off',
      serialsOn: 'Serials: On',
      serialsHidden: 'Hidden (••••••)',
      serialsHiddenBanner: 'Serial numbers are hidden. Enable "Serials" to view and copy.',
      enableSerialsBtn: 'Show Serials',
      serialsShownToast: 'Serial numbers visible',
      serialsHiddenToast: 'Serial numbers hidden',
      noSerials: 'No identifiers available',
      serialEmpty: 'Not reported by firmware / unavailable',
      allSerialsEyebrow: 'All Components Summary',
      allSerialsTitle: 'All PC Serial Numbers & Identifiers',
      processesWord: 'processes',
      pagefileWord: 'Pagefile',
      totalTraffic: 'Total',
      snapshotWord: 'Snapshot',
      noDrives: 'No drives found',
      noData: 'No data',
      ghz: 'GHz',
      mhz: 'MHz',
      gb: 'GB',
      mb: 'MB',
      hz: 'Hz',
      mts: 'MT/s',
      mbps: 'Mbps',
      w: 'W',
      secShort: 's',
      unitsBytes: ['B', 'KB', 'MB', 'GB', 'TB'],
      rateB: 'B/s',
      rateKB: 'KB/s',
      rateMB: 'MB/s',
      gpuFallbackVram: 'No nvidia-smi data',
      gpuFallbackMeta: 'See "Graphics" section below',
      integrated: 'Integrated',
      presets: ['Emerald & Sky', 'Cyberpunk', 'Golden Sunset', 'Neon Violet', 'Crimson Pulse', 'Monochrome'],
    },
    ru: {
      pageTitle: 'StatsPC — Мониторинг и комплектующие ПК',
      tabStats: 'Статистика',
      tabInternet: 'Интернет',
      tabAnalysis: 'Анализ ПК',
      tabSettings: 'Настройки',
      analysisTitle: 'Анализ комплектующих, драйверов и интернета',
      analysisDesc: 'Проверка дисков, ОЗУ, процессора, драйверов, температур, герцовки и скорости интернета',
      runAnalysisBtn: 'Запустить анализ',
      analyzingText: 'Этап 1/2: Анализ комплектующих, драйверов и температур...',
      analyzingInternetText: 'Этап 2/2: Анализ скорости интернета, пинга и потерь пакетов...',
      heavyStorageBtn: 'Игры и папки',
      heavyAppsTitle: 'Тяжёлые игры и приложения',
      heavyFoldersTitle: 'Крупные папки на дисках',
      minSizeFilterLabel: 'Минимальный размер (от 1 ГБ до 1 ТБ)',
      gameKind: 'Игра',
      appKind: 'Прогр.',
      analysisReadyTitle: 'Готово к проверке ПК',
      analysisReadySub: 'Нажмите «Запустить анализ», чтобы проверить компоненты и получить рекомендации',
      analysisIdealTitle: 'Рекомендаций нет — всё работает идеально!',
      analysisIdealSub: 'Все проверенные узлы (диски, память, CPU, GPU, монитор) работают оптимально.',
      analysisFoundTitle: 'Анализ завершён — есть рекомендации',
      analysisFoundSub: 'Время проверки:',
      analysisDoneToast: 'Анализ ПК завершён',
      sevCritical: 'Важно',
      sevWarning: 'Внимание',
      sevTip: 'Совет',
      sevOk: 'Идеально',
      netPageTitle: 'Интернет и тест скорости',
      netPageDesc: 'Замер скорости загрузки и отдачи, пинга, джиттера и доступности DNS-серверов',
      pingCheckBtn: 'Проверить пинг',
      runSpeedTestBtn: 'Запустить тест',
      testingSpeedBtn: 'Тестирование...',
      speedDownLabel: 'Загрузка (Download)',
      speedUpLabel: 'Отдача (Upload)',
      speedPingLabel: 'Пинг / Джиттер',
      ispLabel: 'Подключение и провайдер',
      dnsPingTitle: 'Задержка до серверов (TCP Ping)',
      thServer: 'Сервер',
      thAvg: 'Средний',
      thLoss: 'Потери',
      clickPingHint: 'Нажмите «Проверить пинг» для замера задержки',
      startupAlertsTitle: 'Автозапуск и уведомления о перегреве',
      startupAlertsHint: 'Фоновый режим и пороги',
      autostartTitle: 'Автозапуск с Windows',
      autostartSub: 'Автоматически запускать StatsPC при входе в Windows',
      startMinTitle: 'Запускать свёрнутым в трей',
      startMinSub: 'Сразу прятать окно в системный трей при старте',
      alertsToggleTitle: 'Тревоги перегрева и нагрузки',
      alertsToggleSub: 'Показывать предупреждение при превышении порогов CPU, RAM или GPU',
      thresholdsTitle: 'Пороги тревоги',
      thresholdsSub: 'Предупреждать при превышении этих значений',
      onLabel: 'Вкл',
      offLabel: 'Выкл',
      alertHighCpu: 'Высокая нагрузка CPU',
      alertHighRam: 'Высокая загрузка RAM',
      alertHighGpuTemp: 'Перегрев GPU',
      speedDoneToast: 'Тест скорости завершён',
      shuttingDownTitle: 'Выключение StatsPC...',
      shuttingDownSub: 'До скорой встречи',
      speedPhaseConnecting: 'Подключение к серверу и замер пинга...',
      speedPhaseDownloading: 'Замер скорости загрузки и отдачи...',
      uptimeLabel: 'Аптайм',
      allSerialsBtn: 'Все серийные номера',
      refreshBtn: 'Обновить',
      refreshingBtn: 'Обновление...',
      exportBtn: 'Экспорт JSON',
      exitBtn: 'Выход',
      liveTitle: 'Состояние ПК в этот момент',
      liveDesc: 'Телеметрия в реальном времени • обновление раз в',
      cpuLabel: 'Процессор (CPU)',
      ramLabel: 'Оперативная память (RAM)',
      gpuLabel: 'Видеокарта (GPU)',
      ioLabel: 'Сеть и Диски I/O',
      ioBadge: 'Активность',
      netInLabel: 'Сеть Вход (↓)',
      netOutLabel: 'Сеть Исход (↑)',
      diskReadLabel: 'Диск Чтение',
      diskWriteLabel: 'Диск Запись',
      drivesTitle: 'Логические диски',
      drivesHint: 'Свободное место',
      procsTitle: 'Активные процессы (Топ-8)',
      procsHint: 'По нагрузке CPU / RAM',
      thProc: 'Процесс',
      hwTitle: 'Комплектующие ПК',
      hwDesc: 'Нажмите «Подробнее» на любом компоненте, чтобы увидеть все характеристики и серийные номера',
      settingsTitle: 'Настройки и персонализация',
      settingsDesc: 'Настройте цвета Liquid Glass, язык и частоту обновления — изменения применяются мгновенно',
      resetBtn: 'Сбросить по умолчанию',
      paletteTitle: 'Палитра акцентов',
      paletteHint: 'Свои цвета',
      themeModeTitle: 'Тема оформления',
      themeModeSub: 'Тёмный или светлый стиль Liquid Glass',
      themeDark: 'Тёмная',
      themeLight: 'Светлая',
      primaryColorTitle: 'Основной цвет (акцент)',
      primaryColorSub: 'Кнопки действий, индикатор LIVE, GPU, серийные номера',
      secondaryColorTitle: 'Дополнительный цвет',
      secondaryColorSub: 'График CPU, иконки комплектующих, кнопки «Подробнее», сеть',
      presetsTitle: 'Готовые темы',
      presetsHint: 'В один клик',
      effectsTitle: 'Язык, масштаб и телеметрия',
      effectsHint: 'Требует сохранения',
      unsavedChangesText: 'Есть несохранённые изменения (масштаб, язык или частота)',
      saveBtn: 'Сохранить',
      discardBtn: 'Отмена',
      savedToast: 'Настройки сохранены и применены',
      discardedToast: 'Изменения отменены',
      closeModalEyebrow: 'StatsPC',
      closeModalTitle: 'Закрыть приложение?',
      closeModalDesc: 'Свернуть программу в системный трей для работы в фоне или закрыть полностью?',
      minimizeTrayBtn: 'Свернуть в трей',
      exitCompleteBtn: 'Закрыть полностью',
      langTitle: 'Язык / Language',
      langSub: 'Язык интерфейса (базовый: English)',
      intervalTitle: 'Частота обновления телеметрии',
      intervalSub: 'Как часто опрашиваются датчики CPU, RAM, GPU и сети',
      glowTitle: 'Яркость фонового свечения',
      glowSub: 'Интенсивность цветных сфер за стеклянными карточками',
      zoomTitle: 'Масштаб интерфейса',
      zoomSub: 'Уменьшить или увеличить масштаб всего окна',
      heavyAppsTitle: 'Самые тяжёлые приложения',
      heavyFoldersTitle: 'Самые большие папки на дисках',
      scanningDisk: 'Сканирование приложений и папок на дисках...',
      rescanBtn: 'Пересканировать',
      noHeavyItems: 'Крупные объекты не найдены',
      detailsBtn: 'Подробнее',
      copyBtn: 'Копировать',
      copiedToast: 'Скопировано',
      hwRefreshedToast: 'Конфигурация оборудования обновлена',
      hwRefreshFailToast: 'Не удалось обновить данные оборудования',
      hwLoadError: 'Ошибка при чтении данных оборудования.',
      shutdownToast: 'StatsPC остановлен',
      resetToast: 'Настройки сброшены по умолчанию',
      themeApplied: 'Тема применена',
      langToast: 'Язык: Русский',
      serialsTitle: 'Серийные номера и идентификаторы',
      serialsOff: 'Серийники: Выкл',
      serialsOn: 'Серийники: Вкл',
      serialsHidden: 'Скрыто (••••••)',
      serialsHiddenBanner: 'Серийные номера скрыты. Включите кнопку «Серийники», чтобы увидеть и скопировать.',
      enableSerialsBtn: 'Показать серийники',
      serialsShownToast: 'Серийные номера показаны',
      serialsHiddenToast: 'Серийные номера скрыты',
      noSerials: 'Идентификаторы отсутствуют',
      serialEmpty: 'Не передаётся прошивкой / отсутствует',
      allSerialsEyebrow: 'Сводка по всем комплектующим',
      allSerialsTitle: 'Все серийные номера и идентификаторы ПК',
      processesWord: 'процессов',
      pagefileWord: 'Файл подкачки',
      totalTraffic: 'Всего',
      snapshotWord: 'Снимок',
      noDrives: 'Разделы не найдены',
      noData: 'Нет данных',
      ghz: 'ГГц',
      mhz: 'МГц',
      gb: 'ГБ',
      mb: 'МБ',
      hz: 'Гц',
      mts: 'МТ/с',
      mbps: 'Мбит/с',
      w: 'Вт',
      secShort: 'с',
      unitsBytes: ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'],
      rateB: 'Б/с',
      rateKB: 'КБ/с',
      rateMB: 'МБ/с',
      gpuFallbackVram: 'Нет данных nvidia-smi',
      gpuFallbackMeta: 'См. раздел «Видеокарты» ниже',
      integrated: 'Интегр.',
      presets: ['Изумруд и Небо', 'Киберпанк', 'Золотой Закат', 'Неоновый Фиолет', 'Алый Импульс', 'Чёрно-белый'],
    },
  };

  const THEME_PRESETS = [
    { primary: '#34D399', secondary: '#38BDF8' },
    { primary: '#F472B6', secondary: '#22D3EE' },
    { primary: '#FBBF24', secondary: '#FB7185' },
    { primary: '#A855F7', secondary: '#60A5FA' },
    { primary: '#F87171', secondary: '#FB923C' },
    { primary: '#F8FAFC', secondary: '#94A3B8' },
  ];

  let settings = loadSettings();
  let draftImportant = {
    zoom: settings.zoom,
    lang: settings.lang,
    intervalMs: settings.intervalMs,
  };

  function hasPendingImportantChanges() {
    return (
      Number(draftImportant.zoom) !== Number(settings.zoom) ||
      draftImportant.lang !== settings.lang ||
      Number(draftImportant.intervalMs) !== Number(settings.intervalMs)
    );
  }

  function syncDraftControls() {
    const z = Math.max(75, Math.min(130, Number(draftImportant.zoom) || 100));
    const zoomIn = document.getElementById('zoomRangeInput');
    const zoomTxt = document.getElementById('zoomValueText');
    if (zoomIn) zoomIn.value = z;
    if (zoomTxt) zoomTxt.textContent = `${z}%`;

    document.querySelectorAll('#langGroup .seg-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.lang === draftImportant.lang);
    });
    document.querySelectorAll('#intervalGroup .seg-btn').forEach(btn => {
      btn.classList.toggle('active', Number(btn.dataset.interval) === Number(draftImportant.intervalMs));
    });

    const bar = document.getElementById('settingsSaveBar');
    if (bar) bar.hidden = !hasPendingImportantChanges();
  }

  function t(key) {
    const dict = I18N[settings.lang] || I18N.en;
    return dict[key] ?? I18N.en[key] ?? key;
  }

  function loadSettings() {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : { ...DEFAULT_SETTINGS };
    } catch {
      return { ...DEFAULT_SETTINGS };
    }
  }

  let saveTimerId = null;

  function saveSettings(immediate = false) {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {}
    const pushToServer = () => {
      fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      }).catch(() => {});
    };
    if (immediate) {
      clearTimeout(saveTimerId);
      pushToServer();
    } else {
      clearTimeout(saveTimerId);
      saveTimerId = setTimeout(pushToServer, 200);
    }
  }

  async function syncSettingsFromServer() {
    try {
      const res = await fetch('/api/settings');
      if (!res.ok) return;
      const remote = await res.json();
      if (remote && typeof remote === 'object' && Object.keys(remote).length > 0) {
        settings = { ...DEFAULT_SETTINGS, ...remote };
        draftImportant = {
          zoom: settings.zoom,
          lang: settings.lang,
          intervalMs: settings.intervalMs,
        };
        try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch {}
        applySettings();
        restartLivePolling();
      }
    } catch {}
  }

  function hexToRgb(hex) {
    const clean = hex.replace('#', '');
    const full = clean.length === 3 ? clean.split('').map(c => c + c).join('') : clean;
    const num = parseInt(full, 16);
    if (Number.isNaN(num)) return [52, 211, 153];
    return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
  }

  function hexToRgbTuple(hex) {
    const [r, g, b] = hexToRgb(hex);
    return `${r}, ${g}, ${b}`;
  }

  function makeReadableFg(hex, isLight) {
    const [r, g, b] = hexToRgb(hex);
    const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    if (!isLight && lum < 0.24) {
      // Dark background: lift very dark colors toward light slate/white
      const mix = (c) => Math.round(c + (238 - c) * 0.80);
      return `rgb(${mix(r)}, ${mix(g)}, ${mix(b)})`;
    }
    if (isLight && lum > 0.42) {
      // Light background: darken very bright colors toward deep slate
      const mix = (c) => Math.round(c * 0.38 + 15 * 0.62);
      return `rgb(${mix(r)}, ${mix(g)}, ${mix(b)})`;
    }
    return hex;
  }

  function applyTranslations() {
    document.documentElement.lang = settings.lang;
    document.title = t('pageTitle');
    document.querySelectorAll('[data-i18n]').forEach(el => {
      el.textContent = t(el.getAttribute('data-i18n'));
    });
    const sec = settings.intervalMs / 1000;
    const descVal = document.getElementById('intervalDescVal');
    if (descVal) descVal.textContent = `${sec}${t('secShort')}`;
    const pillLabel = document.querySelector('#liveStatusPill span:last-child');
    if (pillLabel) pillLabel.textContent = `LIVE • ${sec}${t('secShort')}`;
    document.querySelectorAll('#intervalGroup .seg-btn').forEach(btn => {
      const s = Number(btn.dataset.interval) / 1000;
      btn.textContent = `${s}${t('secShort')}`;
    });
    document.querySelectorAll('#langGroup .seg-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.lang === settings.lang);
    });
    const tsBtn = document.getElementById('toggleSerialsBtn');
    const tsLbl = document.getElementById('toggleSerialsLabel');
    if (tsBtn && tsLbl) {
      tsBtn.classList.toggle('btn-toggle-on', Boolean(settings.showSerials));
      tsBtn.setAttribute('aria-pressed', String(Boolean(settings.showSerials)));
      tsLbl.textContent = settings.showSerials ? t('serialsOn') : t('serialsOff');
    }
    if (hardwareData) renderHardware(hardwareData);
    if (lastLiveData) renderLive(lastLiveData);
    if (lastAnalysisData) renderAnalysisReport(lastAnalysisData);
  }

  function maskSerial(val) {
    const clean = (val || '').trim();
    if (!clean) return '--';
    return settings.showSerials ? clean : '••••••••';
  }

  function applySettings() {
    const root = document.documentElement;
    const isLight = settings.themeMode === 'light';
    root.setAttribute('data-theme', isLight ? 'light' : 'dark');
    const greenFg = makeReadableFg(settings.primary, isLight);
    const skyFg = makeReadableFg(settings.secondary, isLight);

    root.style.setProperty('--green', settings.primary);
    root.style.setProperty('--green-fg', greenFg);
    root.style.setProperty('--green-rgb', hexToRgbTuple(settings.primary));
    root.style.setProperty('--sky', settings.secondary);
    root.style.setProperty('--sky-fg', skyFg);
    root.style.setProperty('--sky-rgb', hexToRgbTuple(settings.secondary));
    root.style.setProperty('--glow-opacity', String((settings.glow ?? 55) / 100));

    document.querySelectorAll('#themeModeGroup .seg-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.themeMode === (isLight ? 'light' : 'dark'));
    });

    document.querySelectorAll('#autostartGroup .seg-btn').forEach(btn => {
      btn.classList.toggle('active', (btn.dataset.auto === '1') === Boolean(settings.autostart));
    });
    document.querySelectorAll('#startMinGroup .seg-btn').forEach(btn => {
      btn.classList.toggle('active', (btn.dataset.min === '1') === Boolean(settings.startMinimized));
    });
    document.querySelectorAll('#alertsGroup .seg-btn').forEach(btn => {
      btn.classList.toggle('active', (btn.dataset.alerts === '1') === Boolean(settings.alertsEnabled));
    });
    const gIn = document.getElementById('alertGpuTempInput');
    const cIn = document.getElementById('alertCpuPctInput');
    const rIn = document.getElementById('alertRamPctInput');
    if (gIn) gIn.value = settings.alertGpuTemp ?? 82;
    if (cIn) cIn.value = settings.alertCpuPct ?? 90;
    if (rIn) rIn.value = settings.alertRamPct ?? 90;

    const pIn = document.getElementById('primaryColorInput');
    const sIn = document.getElementById('secondaryColorInput');
    if (pIn) pIn.value = settings.primary;
    if (sIn) sIn.value = settings.secondary;
    const pHex = document.getElementById('primaryColorHex');
    const sHex = document.getElementById('secondaryColorHex');
    if (pHex) pHex.textContent = settings.primary.toUpperCase();
    if (sHex) sHex.textContent = settings.secondary.toUpperCase();

    const glowIn = document.getElementById('glowRangeInput');
    const glowTxt = document.getElementById('glowValueText');
    if (glowIn) glowIn.value = settings.glow;
    if (glowTxt) glowTxt.textContent = `${settings.glow}%`;

    const zoomVal = Math.max(75, Math.min(130, Number(settings.zoom) || 100));
    document.documentElement.style.zoom = String(zoomVal / 100);

    applyTranslations();
    syncDraftControls();
    renderPresets();
    renderSparkline('cpuSparkline', history.cpu, skyFg);
    renderSparkline('ramSparkline', history.ram, isLight ? '#9333EA' : '#C084FC');
    renderSparkline('gpuSparkline', history.gpu, greenFg);
  }

  function renderPresets() {
    const wrap = document.getElementById('presetsGrid');
    if (!wrap) return;
    const names = t('presets');
    wrap.innerHTML = THEME_PRESETS.map((p, idx) => {
      const isActive =
        p.primary.toLowerCase() === settings.primary.toLowerCase() &&
        p.secondary.toLowerCase() === settings.secondary.toLowerCase();
      return `
        <button class="preset-chip ${isActive ? 'active' : ''}" type="button" data-preset="${idx}">
          <span class="preset-dots">
            <span class="preset-dot" style="background:${p.primary}"></span>
            <span class="preset-dot" style="background:${p.secondary}"></span>
          </span>
          <span>${escapeHtml(names[idx] || '')}</span>
        </button>
      `;
    }).join('');

    wrap.querySelectorAll('[data-preset]').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = Number(btn.dataset.preset);
        const p = THEME_PRESETS[idx];
        if (!p) return;
        settings.primary = p.primary;
        settings.secondary = p.secondary;
        saveSettings();
        applySettings();
        showToast(`${t('themeApplied')}: ${t('presets')[idx]}`);
      });
    });
  }

  function restartLivePolling() {
    if (liveTimerId) clearInterval(liveTimerId);
    liveTimerId = setInterval(fetchLive, settings.intervalMs);
  }

  const VENDOR_REPLACEMENTS = [
    [/Корпорация\s+Майкрософт/gi, 'Microsoft Corporation'],
    [/Майкрософт/gi, 'Microsoft'],
    [/Нвидиа|НВИДИА/gi, 'NVIDIA'],
    [/Интел/gi, 'Intel'],
    [/АМД/gi, 'AMD'],
    [/Реалтек/gi, 'Realtek'],
    [/Гигабайт/gi, 'Gigabyte'],
    [/Асус/gi, 'ASUS'],
    [/Самсунг/gi, 'Samsung'],
    [/Кингстон/gi, 'Kingston'],
  ];

  function normalizeVendors(str) {
    let out = String(str);
    for (const [re, rep] of VENDOR_REPLACEMENTS) {
      out = out.replace(re, rep);
    }
    return out;
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return normalizeVendors(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatBytes(bytes, decimals = 1) {
    const sizes = t('unitsBytes');
    if (!bytes || bytes <= 0) return `0 ${sizes[0]}`;
    const k = 1024;
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${(bytes / Math.pow(k, i)).toFixed(decimals)} ${sizes[i]}`;
  }

  function formatRate(bytesPerSec) {
    if (!bytesPerSec || bytesPerSec < 1024) return `${Math.round(bytesPerSec || 0)} ${t('rateB')}`;
    if (bytesPerSec < 1024 * 1024) return `${(bytesPerSec / 1024).toFixed(1)} ${t('rateKB')}`;
    return `${(bytesPerSec / (1024 * 1024)).toFixed(2)} ${t('rateMB')}`;
  }

  function formatUptime(sec) {
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    const hh = String(h).padStart(2, '0');
    const mm = String(m).padStart(2, '0');
    const ss = String(s).padStart(2, '0');
    const dUnit = settings.lang === 'ru' ? 'д' : 'd';
    return d > 0 ? `${d}${dUnit} ${hh}:${mm}:${ss}` : `${hh}:${mm}:${ss}`;
  }

  function pushHistory(arr, val) {
    arr.push(Math.max(0, Math.min(100, Number(val) || 0)));
    if (arr.length > MAX_HISTORY) arr.shift();
  }

  function renderSparkline(containerId, values, color) {
    const el = document.getElementById(containerId);
    if (!el || values.length < 2) return;
    const w = 240;
    const h = 44;
    const step = w / (MAX_HISTORY - 1);
    const offset = (MAX_HISTORY - values.length) * step;

    const points = values.map((v, i) => {
      const x = offset + i * step;
      const y = h - (v / 100) * (h - 6) - 3;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    const firstX = offset.toFixed(1);
    const lastX = (offset + (values.length - 1) * step).toFixed(1);
    const areaPoints = `${firstX},${h} ${points.join(' ')} ${lastX},${h}`;

    el.innerHTML = `
      <svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
        <polygon points="${areaPoints}" fill="${color}" fill-opacity="0.14"></polygon>
        <polyline points="${points.join(' ')}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></polyline>
      </svg>
    `;
  }

  function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.classList.remove('show'), 2200);
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      showToast(`${t('copiedToast')}: ${text}`);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      showToast(`${t('copiedToast')}: ${text}`);
    }
  }

  function renderLive(d) {
    lastLiveData = d;
    document.getElementById('lastTick').textContent = d.timestamp || '--:--:--';
    document.getElementById('uptimeValue').textContent = formatUptime(d.uptime_seconds || 0);

    // CPU
    const cpuPct = d.cpu?.percent ?? 0;
    document.getElementById('cpuPct').textContent = `${cpuPct.toFixed(1)}%`;
    document.getElementById('cpuProcCount').textContent = `${d.cpu?.process_count ?? '--'} ${t('processesWord')}`;
    const freqMhz = d.cpu?.freq_current_mhz;
    document.getElementById('cpuFreqBadge').textContent = freqMhz ? `${(freqMhz / 1000).toFixed(2)} ${t('ghz')}` : `-- ${t('ghz')}`;
    const isLight = settings.themeMode === 'light';
    renderSparkline('cpuSparkline', history.cpu, makeReadableFg(settings.secondary, isLight));

    const cores = d.cpu?.per_core || [];
    const coreWrap = document.getElementById('cpuCoreBars');
    if (coreWrap.children.length !== cores.length) {
      coreWrap.innerHTML = cores.map(() => '<div class="core-bar"><div class="core-bar-fill"></div></div>').join('');
    }
    cores.forEach((val, idx) => {
      const fill = coreWrap.children[idx]?.firstElementChild;
      if (fill) {
        fill.style.height = `${Math.max(4, val)}%`;
        fill.style.background = val > 85 ? 'var(--red)' : val > 60 ? 'var(--amber)' : 'var(--sky)';
      }
    });

    // RAM
    const mem = d.memory || {};
    const ramPct = mem.percent ?? 0;
    document.getElementById('ramPct').textContent = `${ramPct.toFixed(1)}%`;
    document.getElementById('ramTotalBadge').textContent = formatBytes(mem.total_bytes, 0);
    document.getElementById('ramUsedText').textContent = `${formatBytes(mem.used_bytes)} / ${formatBytes(mem.total_bytes, 0)}`;
    document.getElementById('ramProgressBar').style.width = `${ramPct}%`;
    document.getElementById('swapText').textContent = `${t('pagefileWord')}: ${formatBytes(mem.swap_used_bytes)} / ${formatBytes(mem.swap_total_bytes, 0)} (${mem.swap_percent ?? 0}%)`;
    renderSparkline('ramSparkline', history.ram, isLight ? '#9333EA' : '#C084FC');

    // GPU
    const gpuList = d.gpus_live || [];
    if (gpuList.length > 0) {
      const g = gpuList[0];
      const util = g.utilization_pct ?? 0;
      const temp = g.temperature_c;
      const vramUsed = g.memory_used_mb ?? 0;
      const vramTotal = g.memory_total_mb ?? 0;
      const vramPct = vramTotal > 0 ? (vramUsed / vramTotal) * 100 : 0;

      document.getElementById('gpuPct').textContent = `${util.toFixed(0)}%`;
      document.getElementById('gpuTempBadge').textContent = temp !== null ? `${temp.toFixed(0)} °C` : '-- °C';
      document.getElementById('gpuVramText').textContent = `VRAM: ${(vramUsed / 1024).toFixed(1)} / ${(vramTotal / 1024).toFixed(1)} ${t('gb')}`;
      document.getElementById('gpuProgressBar').style.width = `${vramPct.toFixed(1)}%`;
      document.getElementById('gpuMetaText').textContent = `${g.name}${g.power_draw_w ? ` • ${g.power_draw_w.toFixed(0)} ${t('w')}` : ''}${g.clock_mhz ? ` • ${g.clock_mhz.toFixed(0)} ${t('mhz')}` : ''}`;
      renderSparkline('gpuSparkline', history.gpu, makeReadableFg(settings.primary, isLight));
    } else {
      document.getElementById('gpuPct').textContent = 'N/A';
      document.getElementById('gpuTempBadge').textContent = t('integrated');
      document.getElementById('gpuVramText').textContent = t('gpuFallbackVram');
      document.getElementById('gpuMetaText').textContent = t('gpuFallbackMeta');
    }

    // Net & Disk
    const net = d.network || {};
    const disk = d.disk || {};
    document.getElementById('netRxVal').textContent = formatRate(net.rx_bytes_per_sec);
    document.getElementById('netTxVal').textContent = formatRate(net.tx_bytes_per_sec);
    document.getElementById('diskReadVal').textContent = formatRate(disk.read_bytes_per_sec);
    document.getElementById('diskWriteVal').textContent = formatRate(disk.write_bytes_per_sec);
    document.getElementById('netTotalText').textContent = `${t('totalTraffic')}: ↓ ${formatBytes(net.total_rx_bytes)} • ↑ ${formatBytes(net.total_tx_bytes)}`;
    const mirror = document.getElementById('netLiveMirror');
    if (mirror) mirror.textContent = `Live: ↓ ${formatRate(net.rx_bytes_per_sec)} • ↑ ${formatRate(net.tx_bytes_per_sec)}`;

    evaluateAlerts(cpuPct, ramPct, gpuList[0]?.temperature_c ?? null);

    // Partitions
    const parts = disk.partitions || [];
    const partWrap = document.getElementById('partitionsList');
    if (parts.length === 0) {
      partWrap.innerHTML = `<div class="empty-state">${escapeHtml(t('noDrives'))}</div>`;
    } else {
      partWrap.innerHTML = parts.map(p => {
        const pct = p.percent || 0;
        const barCls = pct > 90 ? 'fill-red' : pct > 75 ? 'fill-amber' : 'fill-sky';
        return `
          <div class="part-item">
            <div class="part-top">
              <span class="part-name mono">${escapeHtml(p.mountpoint)} <span class="panel-hint">(${escapeHtml(p.fstype)})</span></span>
              <span class="mono">${formatBytes(p.used_bytes)} / ${formatBytes(p.total_bytes)} (${pct}%)</span>
            </div>
            <div class="progress-track">
              <div class="progress-fill ${barCls}" style="width: ${pct}%"></div>
            </div>
          </div>
        `;
      }).join('');
    }

    // Processes
    const procs = d.top_processes || [];
    const procBody = document.getElementById('processesBody');
    if (procs.length === 0) {
      procBody.innerHTML = `<tr><td colspan="4" class="empty-state">${escapeHtml(t('noData'))}</td></tr>`;
    } else {
      procBody.innerHTML = procs.map(pr => `
        <tr>
          <td>${escapeHtml(pr.name)}</td>
          <td class="num">${pr.pid}</td>
          <td class="num">${pr.cpu_percent.toFixed(1)}%</td>
          <td class="num">${pr.memory_mb.toFixed(0)} ${t('mb')}</td>
        </tr>
      `).join('');
    }
  }

  async function fetchLive() {
    try {
      const res = await fetch('/api/live');
      if (!res.ok) throw new Error('Live fetch error');
      const d = await res.json();
      pushHistory(history.cpu, d.cpu?.percent ?? 0);
      pushHistory(history.ram, d.memory?.percent ?? 0);
      if (d.gpus_live && d.gpus_live.length > 0) {
        pushHistory(history.gpu, d.gpus_live[0].utilization_pct ?? 0);
      }
      renderLive(d);
    } catch (err) {
      console.error(err);
    }
  }

  const ICONS = {
    cpu: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3"/></svg>',
    board: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 7h4v4H7zM14 7h3M14 11h3M7 15h10"/></svg>',
    ram: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="10" rx="2"/><path d="M6 16v3M10 16v3M14 16v3M18 16v3M6 10h2M11 10h2M16 10h2"/></svg>',
    disk: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>',
    gpu: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="8" cy="12" r="2.5"/><circle cx="15" cy="12" r="2.5"/></svg>',
    net: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><circle cx="12" cy="20" r="1"/></svg>',
    monitor: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
    os: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="8" height="8"/><rect x="13" y="3" width="8" height="8"/><rect x="3" y="13" width="8" height="8"/><rect x="13" y="13" width="8" height="8"/></svg>',
  };

  function buildComponentCards(hw) {
    const ru = settings.lang === 'ru';
    const cpu = hw.cpus?.[0] || {};
    const board = hw.motherboard || {};
    const bios = hw.bios || {};
    const rams = hw.ram_modules || [];
    const totalRam = rams.reduce((acc, r) => acc + (r.capacity_bytes || 0), 0);
    const disks = hw.disks || [];
    const gpus = hw.gpus || [];
    const primaryGpu = gpus.find(g => /nvidia|amd|radeon|geforce|rtx|gtx/i.test(g.name || '')) || gpus[0] || {};
    const nets = (hw.network_adapters || []).filter(n => n.physical || n.mac_address);
    const monitors = hw.monitors || [];
    const os = hw.os || {};
    const sys = hw.system || {};

    return [
      {
        id: 'cpu',
        icon: ICONS.cpu,
        category: ru ? 'Процессор' : 'Processor',
        title: cpu.name || (ru ? 'Не определён' : 'Unknown'),
        specs: [
          [ru ? 'Ядра / Потоки' : 'Cores / Threads', `${cpu.cores || '--'} / ${cpu.logical_processors || '--'}`],
          [ru ? 'Макс. частота' : 'Max Clock', cpu.max_clock_mhz ? `${(cpu.max_clock_mhz / 1000).toFixed(2)} ${t('ghz')}` : '--'],
          [ru ? 'Сокет' : 'Socket', cpu.socket || '--'],
          ['Processor ID', maskSerial(cpu.processor_id)],
        ],
        buildModal: () => ({
          eyebrow: ru ? 'Процессор (CPU)' : 'Processor (CPU)',
          title: cpu.name || (ru ? 'Процессор' : 'Processor'),
          serials: (hw.cpus || []).flatMap((c, i) => [
            [`CPU #${i + 1} ProcessorId`, c.processor_id],
            [`CPU #${i + 1} SerialNumber`, c.serial_number],
          ]),
          sections: (hw.cpus || []).map((c, i) => ({
            title: `${ru ? 'Процессор' : 'Processor'} #${i + 1}`,
            rows: [
              [ru ? 'Модель' : 'Model', c.name],
              [ru ? 'Производитель' : 'Manufacturer', c.manufacturer],
              [ru ? 'Сокет' : 'Socket', c.socket],
              [ru ? 'Ядра / Потоки' : 'Cores / Logical', `${c.cores} / ${c.logical_processors}`],
              [ru ? 'Макс. частота' : 'Max Clock', c.max_clock_mhz ? `${c.max_clock_mhz} ${t('mhz')}` : '--'],
              [ru ? 'Кэш L2 / L3' : 'L2 / L3 Cache', `${c.l2_cache_kb || 0} KB / ${c.l3_cache_kb || 0} KB`],
            ],
          })),
        }),
      },
      {
        id: 'board',
        icon: ICONS.board,
        category: ru ? 'Материнская плата & BIOS' : 'Motherboard & BIOS',
        title: `${board.manufacturer || ''} ${board.product || (ru ? 'Не определена' : 'Unknown')}`.trim(),
        specs: [
          [ru ? 'Плата' : 'Board', board.product || '--'],
          ['BIOS', `${bios.version || '--'} (${bios.release_date || '--'})`],
          ['S/N', maskSerial(board.serial_number)],
        ],
        buildModal: () => ({
          eyebrow: ru ? 'Материнская плата и BIOS' : 'Motherboard & BIOS',
          title: `${board.manufacturer || ''} ${board.product || ''}`.trim(),
          serials: [
            [ru ? 'Серийный номер платы (BaseBoard)' : 'Motherboard SerialNumber', board.serial_number],
            [ru ? 'Серийный номер BIOS' : 'BIOS SerialNumber', bios.serial_number],
          ],
          sections: [
            {
              title: ru ? 'Материнская плата' : 'Motherboard',
              rows: [
                [ru ? 'Производитель' : 'Manufacturer', board.manufacturer],
                [ru ? 'Модель' : 'Model', board.product],
                [ru ? 'Ревизия' : 'Revision', board.version],
              ],
            },
            {
              title: 'BIOS / UEFI',
              rows: [
                [ru ? 'Производитель' : 'Vendor', bios.manufacturer],
                [ru ? 'Версия SMBIOS' : 'SMBIOS Version', bios.version],
                [ru ? 'Дата выпуска' : 'Release Date', bios.release_date],
              ],
            },
          ],
        }),
      },
      {
        id: 'ram',
        icon: ICONS.ram,
        category: ru ? 'Оперативная память' : 'Memory (RAM)',
        title: `${formatBytes(totalRam, 0)} (${rams.length} ${ru ? (rams.length === 1 ? 'модуль' : 'модуля') : (rams.length === 1 ? 'module' : 'modules')})`,
        specs: [
          [ru ? 'Слоты' : 'Slots', rams.map(r => r.slot).filter(Boolean).join(', ') || '--'],
          [ru ? 'Частота' : 'Speed', rams[0]?.configured_speed_mhz ? `${rams[0].configured_speed_mhz} ${t('mts')}` : (rams[0]?.speed_mhz ? `${rams[0].speed_mhz} ${t('mts')}` : '--')],
          [ru ? 'Серийные №' : 'Serials', settings.showSerials ? (rams.map(r => r.serial_number).filter(Boolean).join(', ') || '--') : (rams.some(r => r.serial_number) ? '••••••••' : '--')],
        ],
        buildModal: () => ({
          eyebrow: ru ? 'Оперативная память (RAM)' : 'Memory Modules (RAM)',
          title: `${ru ? 'Установлено модулей' : 'Installed modules'}: ${rams.length} (${formatBytes(totalRam, 0)})`,
          serials: rams.flatMap((r, i) => [
            [`${ru ? 'Модуль' : 'Module'} #${i + 1} (${r.slot || 'DIMM'}) SerialNumber`, r.serial_number],
            [`${ru ? 'Модуль' : 'Module'} #${i + 1} (${r.slot || 'DIMM'}) PartNumber`, r.part_number],
          ]),
          sections: rams.map((r, i) => ({
            title: `${ru ? 'Слот' : 'Slot'} ${r.slot || `#${i + 1}`}`,
            rows: [
              [ru ? 'Производитель' : 'Manufacturer', r.manufacturer],
              ['Part Number', r.part_number],
              [ru ? 'Объём' : 'Capacity', formatBytes(r.capacity_bytes, 0)],
              [ru ? 'Номинальная частота' : 'Rated Speed', r.speed_mhz ? `${r.speed_mhz} ${t('mts')}` : '--'],
              [ru ? 'Текущая частота' : 'Configured Speed', r.configured_speed_mhz ? `${r.configured_speed_mhz} ${t('mts')}` : '--'],
              [ru ? 'Банк' : 'Bank', r.bank || '--'],
            ],
          })),
        }),
      },
      {
        id: 'disks',
        icon: ICONS.disk,
        category: ru ? 'Накопители' : 'Storage Drives',
        title: disks[0]?.model || `${ru ? 'Дисков' : 'Drives'}: ${disks.length}`,
        specs: [
          [ru ? 'Всего дисков' : 'Total Drives', String(disks.length)],
          [ru ? 'Интерфейс' : 'Interface', disks[0]?.interface_type || '--'],
          [ru ? 'Объём' : 'Capacity', disks[0]?.size_bytes ? formatBytes(disks[0].size_bytes, 0) : '--'],
          ['S/N', maskSerial(disks[0]?.serial_number)],
        ],
        buildModal: () => ({
          eyebrow: ru ? 'Физические накопители (SSD / HDD)' : 'Physical Storage Drives',
          title: `${ru ? 'Накопителей в системе' : 'Detected drives'}: ${disks.length}`,
          hasDiskHeavy: true,
          serials: disks.flatMap((d, i) => [
            [`${ru ? 'Диск' : 'Drive'} #${i + 1} (${d.model}) SerialNumber`, d.serial_number],
            [`${ru ? 'Диск' : 'Drive'} #${i + 1} PNPDeviceID`, d.pnp_device_id],
          ]),
          sections: disks.map((d, i) => ({
            title: `${ru ? 'Накопитель' : 'Drive'} #${i + 1}: ${d.model}`,
            rows: [
              [ru ? 'Модель' : 'Model', d.model],
              [ru ? 'Объём' : 'Capacity', formatBytes(d.size_bytes, 1)],
              [ru ? 'Интерфейс' : 'Interface', d.interface_type],
              [ru ? 'Тип носителя' : 'Media Type', d.media_type],
              ['Firmware', d.firmware_revision],
              [ru ? 'Разделов' : 'Partitions', String(d.partitions ?? '--')],
              ['Device ID', d.device_id],
            ],
          })),
        }),
      },
      {
        id: 'gpu',
        icon: ICONS.gpu,
        category: ru ? 'Видеокарты' : 'Graphics (GPU)',
        title: primaryGpu.name || (ru ? 'Не определена' : 'Unknown'),
        specs: [
          [ru ? 'Всего адаптеров' : 'Adapters', String(gpus.length)],
          [ru ? 'Драйвер' : 'Driver', primaryGpu.driver_version || '--'],
          ['VRAM', primaryGpu.vram_mb ? `${(primaryGpu.vram_mb / 1024).toFixed(0)} ${t('gb')}` : (primaryGpu.adapter_ram_bytes ? formatBytes(primaryGpu.adapter_ram_bytes, 0) : '--')],
          [ru ? 'Разрешение' : 'Resolution', primaryGpu.resolution ? `${primaryGpu.resolution} @ ${primaryGpu.refresh_rate_hz} ${t('hz')}` : '--'],
        ],
        buildModal: () => ({
          eyebrow: ru ? 'Графические адаптеры (GPU)' : 'Graphics Adapters (GPU)',
          title: `${ru ? 'Видеоадаптеров' : 'Adapters'}: ${gpus.length}`,
          serials: gpus.flatMap((g, i) => [
            [`GPU #${i + 1} (${g.name}) SerialNumber`, g.serial_number],
            [`GPU #${i + 1} NVIDIA UUID`, g.nvidia_uuid],
            [`GPU #${i + 1} PNPDeviceID`, g.pnp_device_id],
          ]),
          sections: gpus.map((g, i) => ({
            title: `${ru ? 'Видеоадаптер' : 'Adapter'} #${i + 1}: ${g.name}`,
            rows: [
              [ru ? 'Название' : 'Name', g.name],
              [ru ? 'Производитель' : 'Vendor', g.adapter_compatibility],
              [ru ? 'Видеопроцессор' : 'Video Processor', g.video_processor],
              [ru ? 'Версия драйвера' : 'Driver Version', g.driver_version],
              [ru ? 'Дата драйвера' : 'Driver Date', g.driver_date],
              ['VBIOS', g.vbios_version || '--'],
              [ru ? 'Разрешение' : 'Resolution', g.resolution ? `${g.resolution} @ ${g.refresh_rate_hz} ${t('hz')}` : '--'],
              [ru ? 'Статус' : 'Status', g.status],
            ],
          })),
        }),
      },
      {
        id: 'net',
        icon: ICONS.net,
        category: ru ? 'Сетевые адаптеры' : 'Network Adapters',
        title: nets[0]?.name || `${ru ? 'Адаптеров' : 'Adapters'}: ${nets.length}`,
        specs: [
          [ru ? 'Физических' : 'Physical', String(nets.length)],
          [ru ? 'MAC-адрес' : 'MAC Address', maskSerial(nets[0]?.mac_address)],
          [ru ? 'Подключение' : 'Connection', nets[0]?.connection_id || '--'],
        ],
        buildModal: () => ({
          eyebrow: ru ? 'Сетевые адаптеры' : 'Network Adapters',
          title: `${ru ? 'Найдено адаптеров' : 'Detected adapters'}: ${nets.length}`,
          serials: nets.flatMap((n, i) => [
            [`${ru ? 'Адаптер' : 'Adapter'} #${i + 1} (${n.connection_id || n.name}) MAC`, n.mac_address],
            [`${ru ? 'Адаптер' : 'Adapter'} #${i + 1} PNPDeviceID`, n.pnp_device_id],
          ]),
          sections: nets.map((n, i) => ({
            title: `${ru ? 'Адаптер' : 'Adapter'} #${i + 1}: ${n.name}`,
            rows: [
              [ru ? 'Подключение' : 'Connection', n.connection_id || '--'],
              [ru ? 'Производитель' : 'Manufacturer', n.manufacturer || '--'],
              [ru ? 'Тип' : 'Type', n.adapter_type || '--'],
              [ru ? 'Скорость линка' : 'Link Speed', n.speed_bps ? `${(n.speed_bps / 1_000_000).toFixed(0)} ${t('mbps')}` : '--'],
            ],
          })),
        }),
      },
      {
        id: 'monitors',
        icon: ICONS.monitor,
        category: ru ? 'Мониторы' : 'Monitors',
        title: monitors[0]?.name || (monitors.length ? `${ru ? 'Мониторов' : 'Monitors'}: ${monitors.length}` : (ru ? 'Не обнаружены' : 'Not detected')),
        specs: [
          [ru ? 'Текущее разр.' : 'Current Res', monitors[0]?.current_resolution || '--'],
          [ru ? 'Макс. разр.' : 'Max Res', monitors[0]?.max_resolution || '--'],
          [ru ? 'Герцовка' : 'Refresh Rate', monitors[0]?.current_hz ? `${monitors[0].current_hz} ${t('hz')} (${ru ? 'макс.' : 'max'} ${monitors[0].max_hz || monitors[0].current_hz} ${t('hz')})` : '--'],
          ['S/N', maskSerial(monitors[0]?.serial_number)],
        ],
        buildModal: () => ({
          eyebrow: ru ? 'Мониторы (EDID / Win32)' : 'Monitors (EDID / Win32)',
          title: `${ru ? 'Подключено мониторов' : 'Connected monitors'}: ${monitors.length}`,
          serials: monitors.flatMap((m, i) => [
            [`${ru ? 'Монитор' : 'Monitor'} #${i + 1} (${m.name || m.product_code}) SerialNumber`, m.serial_number],
            [`${ru ? 'Монитор' : 'Monitor'} #${i + 1} InstanceName`, m.instance_name],
          ]),
          sections: monitors.map((m, i) => ({
            title: `${ru ? 'Монитор' : 'Monitor'} #${i + 1}: ${m.name || m.product_code || 'Display'}`,
            rows: [
              [ru ? 'Текущее разрешение' : 'Current Resolution', m.current_resolution || '--'],
              [ru ? 'Максимальное разрешение' : 'Maximum Resolution', m.max_resolution || '--'],
              [ru ? 'Текущая герцовка' : 'Current Refresh Rate', m.current_hz ? `${m.current_hz} ${t('hz')}` : '--'],
              [ru ? 'Максимальная герцовка' : 'Maximum Refresh Rate', m.max_hz ? `${m.max_hz} ${t('hz')}` : '--'],
              [ru ? 'Видеоадаптер / Выход' : 'Display Adapter', m.display_adapter || m.device_name || '--'],
              [ru ? 'Производитель (ID)' : 'Manufacturer ID', m.manufacturer || '--'],
              [ru ? 'Модель' : 'Model', m.name || '--'],
              [ru ? 'Код продукта' : 'Product Code', m.product_code || '--'],
              [ru ? 'Год / Неделя выпуска' : 'Manufacture Year / Week', m.year_of_manufacture ? `${m.year_of_manufacture} / wk ${m.week_of_manufacture}` : '--'],
            ],
          })),
        }),
      },
      {
        id: 'os',
        icon: ICONS.os,
        category: ru ? 'Система и ОС' : 'System & OS',
        title: os.caption || 'Windows',
        specs: [
          [ru ? 'Версия / Сборка' : 'Version / Build', `${os.version || '--'} (${os.build || '--'})`],
          [ru ? 'Архитектура' : 'Architecture', os.architecture || '--'],
          [ru ? 'Имя ПК' : 'Hostname', sys.hostname || '--'],
          [ru ? 'S/N ОС' : 'OS Serial', maskSerial(os.serial_number)],
        ],
        buildModal: () => ({
          eyebrow: ru ? 'Операционная система и платформа' : 'Operating System & Platform',
          title: os.caption || 'Operating System',
          serials: [
            [ru ? 'Серийный номер ОС (Product ID)' : 'OS Serial Number (Product ID)', os.serial_number],
            [ru ? 'Имя компьютера (Hostname)' : 'Hostname', sys.hostname],
          ],
          sections: [
            {
              title: ru ? 'Сведения об ОС и системе' : 'OS & System Details',
              rows: [
                [ru ? 'Операционная система' : 'Operating System', os.caption],
                [ru ? 'Версия' : 'Version', os.version],
                [ru ? 'Номер сборки' : 'Build Number', os.build],
                [ru ? 'Архитектура' : 'Architecture', os.architecture],
                [ru ? 'Последний запуск' : 'Last Boot Time', os.last_boot],
                [ru ? 'Производитель ПК' : 'System Manufacturer', sys.manufacturer],
                [ru ? 'Модель ПК' : 'System Model', sys.model],
                [ru ? 'Домен / Рабочая группа' : 'Domain / Workgroup', sys.domain],
              ],
            },
          ],
        }),
      },
    ];
  }

  let currentModalConfig = null;

  function renderSerialRows(serials) {
    if (!serials || serials.length === 0) {
      return `<div class="empty-state">${escapeHtml(t('noSerials'))}</div>`;
    }
    if (!settings.showSerials) {
      return `
        <div class="serial-hidden-box" style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
          <span class="serial-empty">${escapeHtml(t('serialsHiddenBanner'))}</span>
          <button class="copy-btn" type="button" id="modalEnableSerialsBtn">${escapeHtml(t('enableSerialsBtn'))}</button>
        </div>
      `;
    }
    const rows = serials.map(([label, value]) => {
      const clean = (value || '').trim();
      const valHtml = clean
        ? `<div class="serial-row-cell">
             <code class="serial-code">${escapeHtml(clean)}</code>
             <button class="copy-btn" type="button" data-copy="${escapeHtml(clean)}">${escapeHtml(t('copyBtn'))}</button>
           </div>`
        : `<span class="serial-empty">${escapeHtml(t('serialEmpty'))}</span>`;
      return `<tr><td class="detail-key">${escapeHtml(label)}</td><td class="detail-val">${valHtml}</td></tr>`;
    }).join('');
    return `<table class="detail-table"><tbody>${rows}</tbody></table>`;
  }

  function openDetailsModal(modalConfig) {
    currentModalConfig = modalConfig;
    document.getElementById('modalEyebrow').textContent = modalConfig.eyebrow;
    document.getElementById('modalTitle').textContent = modalConfig.title;

    const serialsBlock = `
      <div class="detail-block serials-highlight">
        <div class="detail-block-title">
          <span>${escapeHtml(t('serialsTitle'))}</span>
        </div>
        ${renderSerialRows(modalConfig.serials)}
      </div>
    `;

    const sectionsHtml = (modalConfig.sections || []).map(sec => {
      const rows = (sec.rows || []).map(([k, v]) => `
        <tr>
          <td class="detail-key">${escapeHtml(k)}</td>
          <td class="detail-val mono">${escapeHtml(v || '--')}</td>
        </tr>
      `).join('');
      return `
        <div class="detail-block">
          <div class="detail-block-title"><span>${escapeHtml(sec.title)}</span></div>
          <table class="detail-table"><tbody>${rows}</tbody></table>
        </div>
      `;
    }).join('');

    const body = document.getElementById('modalBody');
    const minGb = Math.max(1, Math.min(1000, Number(settings.diskMinGb) || 1));
    const diskHeavyPlaceholder = modalConfig.hasDiskHeavy
      ? `<div class="detail-block" id="diskHeavyBlock">
           <div class="detail-block-title">
             <span>${escapeHtml(t('heavyAppsTitle'))} & ${escapeHtml(t('heavyFoldersTitle'))} (≥ ${minGb >= 1000 ? '1 TB' : `${minGb} ${t('gb')}`})</span>
             <div style="display:flex;align-items:center;gap:8px;">
               <button class="copy-btn" type="button" id="rescanDiskHeavyBtn">${escapeHtml(t('rescanBtn'))}</button>
               <button class="dots-menu-btn" type="button" id="diskHeavyDotsBtn" title="Filter">
                 <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                   <circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/>
                 </svg>
               </button>
             </div>
           </div>
           <div class="disk-filter-pop" id="diskHeavyFilterPop" hidden>
             <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;">
               <span style="font-size:0.8rem;font-weight:600;">${escapeHtml(t('minSizeFilterLabel'))}</span>
               <div style="display:flex;align-items:center;gap:6px;">
                 <input type="number" id="diskMinGbInput" class="thresh-input mono" min="1" max="1000" value="${minGb}" />
                 <span class="mono" style="font-size:0.78rem;color:var(--fg-muted);" id="diskMinGbUnit">${minGb >= 1000 ? 'TB (1000 GB)' : t('gb')}</span>
               </div>
             </div>
             <input type="range" id="diskMinGbRange" min="1" max="1000" value="${minGb}" style="width:100%;accent-color:var(--sky);cursor:pointer;" />
           </div>
           <div id="diskHeavyContent" class="empty-state">${escapeHtml(t('scanningDisk'))}</div>
         </div>`
      : '';
    body.innerHTML = serialsBlock + diskHeavyPlaceholder + sectionsHtml;
    body.querySelectorAll('[data-copy]').forEach(btn => {
      btn.addEventListener('click', () => copyText(btn.getAttribute('data-copy')));
    });
    if (modalConfig.hasDiskHeavy) {
      loadDiskHeavyIntoModal(false);
      document.getElementById('rescanDiskHeavyBtn')?.addEventListener('click', () => loadDiskHeavyIntoModal(true));
      document.getElementById('diskHeavyDotsBtn')?.addEventListener('click', () => {
        const pop = document.getElementById('diskHeavyFilterPop');
        if (pop) pop.hidden = !pop.hidden;
      });
      let filterTimer = null;
      const applyDiskMinGb = (val) => {
        const clamped = Math.max(1, Math.min(1000, Number(val) || 1));
        settings.diskMinGb = clamped;
        saveSettings(false);
        const rEl = document.getElementById('diskMinGbRange');
        const iEl = document.getElementById('diskMinGbInput');
        const uEl = document.getElementById('diskMinGbUnit');
        const titleSpan = document.querySelector('#diskHeavyBlock .detail-block-title > span');
        if (rEl && Number(rEl.value) !== clamped) rEl.value = clamped;
        if (iEl && Number(iEl.value) !== clamped) iEl.value = clamped;
        if (uEl) uEl.textContent = clamped >= 1000 ? 'TB (1000 GB)' : t('gb');
        if (titleSpan) titleSpan.textContent = `${t('heavyAppsTitle')} & ${t('heavyFoldersTitle')} (≥ ${clamped >= 1000 ? '1 TB' : `${clamped} ${t('gb')}`})`;
        clearTimeout(filterTimer);
        filterTimer = setTimeout(() => loadDiskHeavyIntoModal(false), 120);
      };
      document.getElementById('diskMinGbRange')?.addEventListener('input', (e) => applyDiskMinGb(e.target.value));
      document.getElementById('diskMinGbInput')?.addEventListener('input', (e) => applyDiskMinGb(e.target.value));
    }
    const enableBtn = document.getElementById('modalEnableSerialsBtn');
    if (enableBtn) {
      enableBtn.addEventListener('click', () => {
        settings.showSerials = true;
        saveSettings();
        applySettings();
        openDetailsModal(currentModalConfig);
        showToast(t('serialsShownToast'));
      });
    }

    const backdrop = document.getElementById('detailsModal');
    backdrop.classList.add('open');
    backdrop.setAttribute('aria-hidden', 'false');
  }

  async function loadDiskHeavyIntoModal(refresh = false) {
    const target = document.getElementById('diskHeavyContent');
    if (!target) return;
    if (refresh) {
      target.innerHTML = `<div class="empty-state">${escapeHtml(t('scanningDisk'))}</div>`;
    }
    try {
      const minGb = Math.max(1, Math.min(1000, Number(settings.diskMinGb) || 1));
      const url = `/api/disk-heavy?min_gb=${minGb}${refresh ? '&refresh=1' : ''}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const apps = data.top_apps || [];
      const folders = data.top_folders || [];

      const renderList = (items, isFolder) => {
        if (!items.length) return `<div class="empty-state">${escapeHtml(t('noHeavyItems'))}</div>`;
        const maxSz = Math.max(...items.map(x => x.size_bytes || 1), 1);
        return items.map(item => {
          const pct = Math.max(4, Math.round(((item.size_bytes || 0) / maxSz) * 100));
          const sub = isFolder ? item.path : (item.location || '');
          const kindTag = !isFolder
            ? `<span class="kind-pill ${item.kind === 'game' ? 'kind-game' : 'kind-app'}">${escapeHtml(item.kind === 'game' ? t('gameKind') : t('appKind'))}</span>`
            : '';
          return `
            <div class="heavy-bar-row" style="margin-bottom:10px;">
              <div class="heavy-bar-top">
                <div style="min-width:0;">
                  <div class="heavy-name">${escapeHtml(item.name)}${kindTag}</div>
                  ${sub ? `<div class="heavy-path mono">${escapeHtml(sub)}</div>` : ''}
                </div>
                <span class="heavy-size">${formatBytes(item.size_bytes, 2)}</span>
              </div>
              <div class="progress-track" style="height:6px;">
                <div class="progress-fill ${isFolder ? 'fill-green' : 'fill-sky'}" style="width:${pct}%"></div>
              </div>
            </div>
          `;
        }).join('');
      };

      target.innerHTML = `
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-top:6px;">
          <div>
            <div style="font-size:0.8rem;font-weight:600;color:var(--sky);margin-bottom:8px;">${escapeHtml(t('heavyAppsTitle'))}</div>
            ${renderList(apps, false)}
          </div>
          <div>
            <div style="font-size:0.8rem;font-weight:600;color:var(--green);margin-bottom:8px;">${escapeHtml(t('heavyFoldersTitle'))}</div>
            ${renderList(folders, true)}
          </div>
        </div>
      `;
    } catch (err) {
      console.error(err);
      target.innerHTML = `<div class="empty-state">${escapeHtml(t('hwLoadError'))}</div>`;
    }
  }

  function closeDetailsModal() {
    const backdrop = document.getElementById('detailsModal');
    backdrop.classList.remove('open');
    backdrop.setAttribute('aria-hidden', 'true');
  }

  function openAllSerialsModal() {
    if (!hardwareData) return;
    const cards = buildComponentCards(hardwareData);
    const allSerials = [];
    cards.forEach(c => {
      const m = c.buildModal();
      (m.serials || []).forEach(pair => allSerials.push(pair));
    });
    openDetailsModal({
      eyebrow: t('allSerialsEyebrow'),
      title: t('allSerialsTitle'),
      serials: allSerials,
      sections: [],
    });
  }

  function renderHardware(hw) {
    hardwareData = hw;
    const osCaption = normalizeVendors(hw.os?.caption || 'Windows');
    const host = hw.system?.hostname || hw.platform_node || 'PC';
    document.getElementById('hostSubtitle').textContent = `${host} • ${osCaption} • ${t('snapshotWord')}: ${hw.collected_at || ''}`;

    const cards = buildComponentCards(hw);
    const grid = document.getElementById('componentsGrid');
    grid.innerHTML = cards.map(c => `
      <article class="card comp-card">
        <div class="comp-head">
          <div class="comp-icon" aria-hidden="true">${c.icon}</div>
          <div>
            <div class="comp-category">${escapeHtml(c.category)}</div>
            <h3 class="comp-name">${escapeHtml(c.title)}</h3>
          </div>
        </div>
        <div class="comp-specs">
          ${c.specs.map(([k, v]) => `
            <div class="comp-spec-row">
              <span class="comp-spec-key">${escapeHtml(k)}</span>
              <span class="comp-spec-val mono" title="${escapeHtml(v)}">${escapeHtml(v)}</span>
            </div>
          `).join('')}
        </div>
        <button class="btn btn-details" type="button" data-comp="${c.id}">
          <span>${escapeHtml(t('detailsBtn'))}</span>
        </button>
      </article>
    `).join('');

    grid.querySelectorAll('[data-comp]').forEach(btn => {
      const id = btn.getAttribute('data-comp');
      const card = cards.find(c => c.id === id);
      if (card) {
        btn.addEventListener('click', () => openDetailsModal(card.buildModal()));
      }
    });
  }

  async function loadHardware(refresh = false) {
    const btn = document.getElementById('refreshHwBtn');
    const btnSpan = btn?.querySelector('span');
    if (refresh && btn) {
      btn.disabled = true;
      if (btnSpan) btnSpan.textContent = t('refreshingBtn');
    }
    try {
      const res = await fetch(refresh ? '/api/hardware?refresh=1' : '/api/hardware');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const hw = await res.json();
      if (hw.error) throw new Error(hw.error);
      renderHardware(hw);
      if (refresh) showToast(t('hwRefreshedToast'));
    } catch (err) {
      console.error(err);
      if (refresh && hardwareData) {
        showToast(t('hwRefreshFailToast'));
      } else if (!hardwareData) {
        document.getElementById('componentsGrid').innerHTML = `<div class="empty-state">${escapeHtml(t('hwLoadError'))}</div>`;
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        if (btnSpan) btnSpan.textContent = t('refreshBtn');
      }
    }
  }

  // Event Listeners
  document.getElementById('closeModalBtn').addEventListener('click', closeDetailsModal);
  document.getElementById('detailsModal').addEventListener('click', (e) => {
    if (e.target.id === 'detailsModal') closeDetailsModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeDetailsModal();
      closeConfirmModal();
    }
  });

  function openConfirmModal() {
    const m = document.getElementById('closeConfirmModal');
    if (!m) return;
    m.classList.add('open');
    m.setAttribute('aria-hidden', 'false');
    setTimeout(() => document.getElementById('confirmMinimizeBtn')?.focus(), 50);
  }

  function closeConfirmModal() {
    const m = document.getElementById('closeConfirmModal');
    if (!m) return;
    m.classList.remove('open');
    m.setAttribute('aria-hidden', 'true');
  }

  window.__onCloseRequested = () => {
    openConfirmModal();
  };

  document.getElementById('closeConfirmXBtn')?.addEventListener('click', closeConfirmModal);
  document.getElementById('confirmCancelBtn')?.addEventListener('click', closeConfirmModal);
  document.getElementById('closeConfirmModal')?.addEventListener('click', (e) => {
    if (e.target.id === 'closeConfirmModal') closeConfirmModal();
  });
  document.getElementById('confirmMinimizeBtn')?.addEventListener('click', async () => {
    closeConfirmModal();
    try {
      await fetch('/api/minimize-tray');
    } catch {}
  });
  async function triggerAnimatedShutdown() {
    closeConfirmModal();
    closeDetailsModal();
    const shell = document.getElementById('appShell');
    const overlay = document.getElementById('shutdownOverlay');
    if (shell) shell.classList.add('app-closing');
    if (overlay) overlay.hidden = false;
    setTimeout(async () => {
      try {
        await fetch('/api/shutdown');
      } catch {}
      setTimeout(() => window.close(), 200);
    }, 440);
  }

  document.getElementById('confirmExitBtn')?.addEventListener('click', triggerAnimatedShutdown);
  document.getElementById('refreshHwBtn').addEventListener('click', () => loadHardware(true));
  document.getElementById('toggleSerialsBtn').addEventListener('click', () => {
    settings.showSerials = !settings.showSerials;
    saveSettings();
    applySettings();
    if (document.getElementById('detailsModal').classList.contains('open') && currentModalConfig) {
      openDetailsModal(currentModalConfig);
    }
    showToast(settings.showSerials ? t('serialsShownToast') : t('serialsHiddenToast'));
  });
  document.getElementById('allSerialsBtn').addEventListener('click', openAllSerialsModal);
  document.getElementById('shutdownBtn').addEventListener('click', triggerAnimatedShutdown);

  const alertCooldowns = { cpu: 0, ram: 0, gpu: 0 };

  function evaluateAlerts(cpuPct, ramPct, gpuTemp) {
    const banner = document.getElementById('alertBanner');
    const bannerTxt = document.getElementById('alertBannerText');
    const cpuCard = document.getElementById('cpuPct')?.closest('.metric-card');
    const ramCard = document.getElementById('ramPct')?.closest('.metric-card');
    const gpuCard = document.getElementById('gpuPct')?.closest('.metric-card');

    if (!settings.alertsEnabled) {
      if (banner) banner.hidden = true;
      cpuCard?.classList.remove('card-alert');
      ramCard?.classList.remove('card-alert');
      gpuCard?.classList.remove('card-alert');
      return;
    }

    const alerts = [];
    const now = Date.now();
    const cpuLim = Number(settings.alertCpuPct) || 90;
    const ramLim = Number(settings.alertRamPct) || 90;
    const gpuLim = Number(settings.alertGpuTemp) || 82;

    const cpuOver = cpuPct >= cpuLim;
    const ramOver = ramPct >= ramLim;
    const gpuOver = gpuTemp !== null && gpuTemp >= gpuLim;

    cpuCard?.classList.toggle('card-alert', cpuOver);
    ramCard?.classList.toggle('card-alert', ramOver);
    gpuCard?.classList.toggle('card-alert', gpuOver);

    if (cpuOver) alerts.push(`${t('alertHighCpu')}: ${cpuPct.toFixed(0)}%`);
    if (ramOver) alerts.push(`${t('alertHighRam')}: ${ramPct.toFixed(0)}%`);
    if (gpuOver) alerts.push(`${t('alertHighGpuTemp')}: ${gpuTemp.toFixed(0)} °C`);

    if (alerts.length > 0) {
      if (banner && bannerTxt) {
        bannerTxt.textContent = alerts.join(' • ');
        banner.hidden = false;
      }
      if ((cpuOver && now - alertCooldowns.cpu > 45000) ||
          (ramOver && now - alertCooldowns.ram > 45000) ||
          (gpuOver && now - alertCooldowns.gpu > 45000)) {
        if (cpuOver) alertCooldowns.cpu = now;
        if (ramOver) alertCooldowns.ram = now;
        if (gpuOver) alertCooldowns.gpu = now;
        showToast(alerts[0]);
      }
    } else if (banner) {
      banner.hidden = true;
    }
  }

  let pingInitialized = false;

  function animateNumber(el, target, decimals = 1, suffix = '') {
    if (!el || target === null || target === undefined) return;
    const duration = 480;
    const start = performance.now();
    const step = (now) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = `${(target * eased).toFixed(decimals)}${suffix}`;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  async function runPingCheck() {
    const btn = document.getElementById('pingCheckBtn');
    if (btn) {
      btn.disabled = true;
      btn.classList.add('is-testing');
    }
    try {
      const res = await fetch('/api/net-info');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      document.getElementById('localIpText').textContent = `Local IP: ${data.local_ip || '--'}`;
      document.getElementById('pingCheckedAt').textContent = data.checked_at || '--';
      const tbody = document.getElementById('pingTableBody');
      const rows = data.pings || [];
      if (!rows.length) {
        tbody.innerHTML = `<tr><td colspan="6" class="empty-state">${escapeHtml(t('noData'))}</td></tr>`;
      } else {
        tbody.innerHTML = rows.map((p, idx) => {
          const cls = p.avg_ms === null ? 'ping-bad' : p.avg_ms < 30 ? 'ping-good' : p.avg_ms < 80 ? 'ping-mid' : 'ping-bad';
          return `
            <tr class="ping-row-anim" style="animation-delay:${idx * 65}ms">
              <td>${escapeHtml(p.label)}</td>
              <td class="mono">${escapeHtml(p.host)}</td>
              <td class="num"><span class="ping-badge ${cls}">${p.avg_ms !== null ? `${p.avg_ms} ms` : 'Timeout'}</span></td>
              <td class="num">${p.min_ms !== null ? `${p.min_ms} / ${p.max_ms} ms` : '--'}</td>
              <td class="num">${p.jitter_ms !== null ? `${p.jitter_ms} ms` : '--'}</td>
              <td class="num">${p.loss_pct}%</td>
            </tr>
          `;
        }).join('');
      }
      if (rows[0]?.avg_ms !== null && document.getElementById('speedPingVal').textContent === '--') {
        animateNumber(document.getElementById('speedPingVal'), rows[0].avg_ms, 1, ' ms');
        document.getElementById('speedJitterVal').textContent = `Jitter: ${rows[0].jitter_ms ?? 0} ms`;
      }
    } catch (err) {
      console.error(err);
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.classList.remove('is-testing');
      }
    }
  }

  async function runSpeedTest() {
    const btn = document.getElementById('runSpeedTestBtn');
    const lbl = btn?.querySelector('span');
    const radar = document.getElementById('speedRadarBanner');
    const phaseEl = document.getElementById('speedPhaseText');
    const inetCards = document.querySelectorAll('#viewInternet .metric-card');

    if (btn) {
      btn.disabled = true;
      btn.classList.add('is-testing');
    }
    if (lbl) lbl.textContent = t('testingSpeedBtn');
    if (radar) radar.hidden = false;
    if (phaseEl) phaseEl.textContent = t('speedPhaseConnecting');
    inetCards.forEach(c => c.classList.add('testing-glow'));

    const phaseTimer = setTimeout(() => {
      if (phaseEl) phaseEl.textContent = t('speedPhaseDownloading');
    }, 900);

    document.getElementById('speedDownVal').textContent = '...';
    document.getElementById('speedUpVal').textContent = '...';
    try {
      const res = await fetch('/api/speedtest');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const d = await res.json();
      if (d.download_mbps !== null) animateNumber(document.getElementById('speedDownVal'), d.download_mbps, 1);
      else document.getElementById('speedDownVal').textContent = 'ERR';
      if (d.upload_mbps !== null) animateNumber(document.getElementById('speedUpVal'), d.upload_mbps, 1);
      else document.getElementById('speedUpVal').textContent = 'ERR';
      if (d.ping_ms !== null) animateNumber(document.getElementById('speedPingVal'), d.ping_ms, 1, ' ms');
      else document.getElementById('speedPingVal').textContent = '--';
      document.getElementById('speedJitterVal').textContent = `Jitter: ${d.jitter_ms ?? '--'} ms`;
      document.getElementById('speedServerBadge').textContent = d.server || 'Cloudflare';
      document.getElementById('speedTestedAt').textContent = d.tested_at || '--';
      document.getElementById('publicIpVal').textContent = d.public_ip || '--';
      document.getElementById('ispNameText').textContent = d.isp || '--';
      document.getElementById('countryBadge').textContent = d.country || '--';
      showToast(t('speedDoneToast'));
      runPingCheck();
    } catch (err) {
      console.error(err);
      document.getElementById('speedDownVal').textContent = 'ERR';
      document.getElementById('speedUpVal').textContent = 'ERR';
    } finally {
      clearTimeout(phaseTimer);
      if (radar) radar.hidden = true;
      inetCards.forEach(c => c.classList.remove('testing-glow'));
      if (btn) {
        btn.disabled = false;
        btn.classList.remove('is-testing');
      }
      if (lbl) lbl.textContent = t('runSpeedTestBtn');
    }
  }

  let lastAnalysisData = null;

  function renderAnalysisReport(rep) {
    lastAnalysisData = rep;
    const ru = settings.lang === 'ru';
    const scoreEl = document.getElementById('analysisScoreVal');
    if (scoreEl) animateNumber(scoreEl, rep.score ?? 100, 0);

    const vTitle = document.getElementById('analysisVerdictTitle');
    const vSub = document.getElementById('analysisVerdictSub');
    if (rep.status === 'ideal' || !rep.recommendations?.length) {
      if (vTitle) vTitle.textContent = t('analysisIdealTitle');
      if (vSub) vSub.textContent = `${t('analysisIdealSub')} (${rep.analyzed_at || ''})`;
    } else {
      if (vTitle) vTitle.textContent = t('analysisFoundTitle');
      if (vSub) vSub.textContent = `${t('analysisFoundSub')} ${rep.analyzed_at || ''}`;
    }

    const checksWrap = document.getElementById('analysisChecksGrid');
    if (checksWrap) {
      checksWrap.innerHTML = (rep.checks || []).map((c, idx) => {
        const badgeCls = c.status === 'critical' ? 'ping-bad' : c.status === 'warning' ? 'ping-mid' : 'ping-good';
        const badgeTxt = c.status === 'critical' ? t('sevCritical') : c.status === 'warning' ? t('sevWarning') : 'OK';
        return `
          <div class="check-pill-card" style="animation-delay:${idx * 50}ms">
            <div class="check-pill-top">
              <span>${escapeHtml(ru ? c.label_ru : c.label_en)}</span>
              <span class="ping-badge ${badgeCls}">${escapeHtml(badgeTxt)}</span>
            </div>
            <div class="check-pill-val mono">${escapeHtml(c.value)}</div>
          </div>
        `;
      }).join('');
    }

    const recsWrap = document.getElementById('analysisRecsList');
    if (recsWrap) {
      const recs = rep.recommendations || [];
      if (!recs.length) {
        recsWrap.innerHTML = `
          <div class="rec-card rec-ideal">
            <div>
              <div class="rec-title">${escapeHtml(t('analysisIdealTitle'))}</div>
              <div class="rec-detail">${escapeHtml(t('analysisIdealSub'))}</div>
            </div>
            <span class="ping-badge ping-good">${escapeHtml(t('sevOk'))}</span>
          </div>
        `;
      } else {
        recsWrap.innerHTML = recs.map((r, idx) => {
          const cls = r.severity === 'critical' ? 'rec-critical' : r.severity === 'warning' ? 'rec-warning' : 'rec-tip';
          const badgeCls = r.severity === 'critical' ? 'ping-bad' : r.severity === 'warning' ? 'ping-mid' : 'badge-sky';
          const sevLbl = r.severity === 'critical' ? t('sevCritical') : r.severity === 'warning' ? t('sevWarning') : t('sevTip');
          return `
            <div class="rec-card ${cls}" style="animation-delay:${idx * 60}ms">
              <div>
                <div class="rec-title">${escapeHtml(ru ? r.title_ru : r.title_en)}</div>
                <div class="rec-detail">${escapeHtml(ru ? r.detail_ru : r.detail_en)}</div>
              </div>
              <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;flex-shrink:0;">
                <span class="ping-badge ${badgeCls}">${escapeHtml(sevLbl)}</span>
                <span class="mono" style="font-size:0.78rem;color:var(--fg-muted);">${escapeHtml(r.metric)}</span>
              </div>
            </div>
          `;
        }).join('');
      }
    }
  }

  async function runPcAnalysis() {
    const btn = document.getElementById('runAnalysisBtn');
    const radar = document.getElementById('analysisRadarBanner');
    const phaseEl = document.getElementById('analysisPhaseText');
    if (btn) {
      btn.disabled = true;
      btn.classList.add('is-testing');
    }
    if (radar) radar.hidden = false;
    if (phaseEl) phaseEl.textContent = t('analyzingText');
    try {
      // Phase 1: Hardware, drivers, displays & storage
      const [res] = await Promise.all([
        fetch('/api/analyze'),
        new Promise(r => setTimeout(r, 500)),
      ]);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const rep = await res.json();
      if (rep.error) throw new Error(rep.error);
      renderAnalysisReport(rep);

      // Phase 2: Immediately run Internet analysis after hardware & drivers
      if (phaseEl) phaseEl.textContent = t('analyzingInternetText');
      let netCheckStatus = 'ok';
      let netCheckVal = 'OK';
      let netPenalty = 0;

      try {
        const [niRes, stRes] = await Promise.all([fetch('/api/net-info'), fetch('/api/speedtest')]);
        const ni = niRes.ok ? await niRes.json() : null;
        const st = stRes.ok ? await stRes.json() : null;
        const maxLoss = Math.max(0, ...((ni?.pings || []).map(p => p.loss_pct || 0)));
        const pingMs = st?.ping_ms ?? ni?.pings?.[0]?.avg_ms ?? null;
        const down = st?.download_mbps ?? null;
        const up = st?.upload_mbps ?? null;

        if (down === null && pingMs === null) {
          netCheckStatus = 'critical';
          netCheckVal = 'Offline / Error';
          netPenalty += 18;
          rep.recommendations.push({
            severity: 'critical',
            category: 'internet',
            title_en: 'No internet connection or speed test unreachable',
            title_ru: 'Нет подключения к интернету или сервер недоступен',
            detail_en: 'Check your Ethernet/Wi-Fi adapter, router, or DNS settings.',
            detail_ru: 'Проверьте кабель Ethernet / Wi-Fi, роутер или настройки DNS.',
            metric: 'Offline',
          });
        } else {
          const dStr = down !== null ? `${down.toFixed(1)}` : '--';
          const uStr = up !== null ? `${up.toFixed(1)}` : '--';
          const pStr = pingMs !== null ? `${pingMs} ms` : '--';
          netCheckVal = `${dStr}/${uStr} Mbps • ${pStr}`;

          if (maxLoss > 0) {
            netCheckStatus = 'warning';
            netPenalty += 10;
            rep.recommendations.push({
              severity: 'warning',
              category: 'internet',
              title_en: 'Packet loss detected on network',
              title_ru: 'Обнаружена потеря пакетов в сети',
              detail_en: `TCP ping measured up to ${maxLoss}% packet loss. Check Wi-Fi signal or cable.`,
              detail_ru: `При проверке серверов зафиксирована потеря пакетов до ${maxLoss}%. Проверьте Wi-Fi или кабель.`,
              metric: `${maxLoss}% loss`,
            });
          }
          if (pingMs !== null && pingMs > 85) {
            if (netCheckStatus === 'ok') netCheckStatus = 'warning';
            netPenalty += 6;
            rep.recommendations.push({
              severity: 'tip',
              category: 'internet',
              title_en: 'High internet latency (Ping)',
              title_ru: 'Высокий пинг в интернете',
              detail_en: `Latency is ${pingMs} ms. Switch to wired Ethernet or close background downloads.`,
              detail_ru: `Задержка составляет ${pingMs} мс. Используйте проводное подключение или остановите фоновые загрузки.`,
              metric: `${pingMs} ms`,
            });
          }
          if (down !== null && down < 15) {
            if (netCheckStatus === 'ok') netCheckStatus = 'warning';
            netPenalty += 6;
            rep.recommendations.push({
              severity: 'tip',
              category: 'internet',
              title_en: 'Low download bandwidth',
              title_ru: 'Низкая скорость загрузки интернета',
              detail_en: `Measured download speed is ${down.toFixed(1)} Mbps (upload ${uStr} Mbps).`,
              detail_ru: `Скорость загрузки всего ${down.toFixed(1)} Мбит/с (отдача ${uStr} Мбит/с).`,
              metric: `${down.toFixed(1)} Mbps`,
            });
          }
        }
      } catch {
        netCheckStatus = 'warning';
        netCheckVal = 'Check failed';
      }

      rep.checks.push({
        label_en: 'Internet',
        label_ru: 'Интернет',
        status: netCheckStatus,
        value: netCheckVal,
      });
      rep.score = Math.max(0, Math.min(100, (rep.score ?? 100) - netPenalty));
      rep.status = rep.recommendations.length === 0 ? 'ideal' : rep.score >= 80 ? 'good' : 'attention';
      renderAnalysisReport(rep);
      showToast(t('analysisDoneToast'));
    } catch (err) {
      console.error(err);
      showToast(t('hwLoadError'));
    } finally {
      if (radar) radar.hidden = true;
      if (btn) {
        btn.disabled = false;
        btn.classList.remove('is-testing');
      }
    }
  }

  function switchTab(tabName) {
    const views = {
      stats: document.getElementById('viewStats'),
      internet: document.getElementById('viewInternet'),
      analysis: document.getElementById('viewAnalysis'),
      settings: document.getElementById('viewSettings'),
    };
    const btns = {
      stats: document.getElementById('tabStatsBtn'),
      internet: document.getElementById('tabInternetBtn'),
      analysis: document.getElementById('tabAnalysisBtn'),
      settings: document.getElementById('tabSettingsBtn'),
    };
    Object.keys(views).forEach(k => {
      const active = k === tabName;
      if (views[k]) {
        views[k].hidden = !active;
        views[k].classList.toggle('active', active);
      }
      if (btns[k]) {
        btns[k].classList.toggle('active', active);
        btns[k].setAttribute('aria-selected', String(active));
      }
    });
    if (tabName === 'internet' && !pingInitialized) {
      pingInitialized = true;
      runPingCheck();
    }
    if (tabName === 'analysis' && !lastAnalysisData) {
      runPcAnalysis();
    }
  }

  document.getElementById('tabStatsBtn').addEventListener('click', () => switchTab('stats'));
  document.getElementById('tabInternetBtn').addEventListener('click', () => switchTab('internet'));
  document.getElementById('tabAnalysisBtn').addEventListener('click', () => switchTab('analysis'));
  document.getElementById('tabSettingsBtn').addEventListener('click', () => switchTab('settings'));
  document.getElementById('runAnalysisBtn').addEventListener('click', runPcAnalysis);
  document.getElementById('openHeavyStorageBtn')?.addEventListener('click', () => {
    if (!hardwareData) return;
    const cards = buildComponentCards(hardwareData);
    const diskCard = cards.find(c => c.id === 'disks');
    if (diskCard) openDetailsModal(diskCard.buildModal());
  });
  document.getElementById('pingCheckBtn').addEventListener('click', runPingCheck);
  document.getElementById('runSpeedTestBtn').addEventListener('click', runSpeedTest);

  document.querySelectorAll('#autostartGroup .seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      settings.autostart = btn.dataset.auto === '1';
      saveSettings(true);
      applySettings();
    });
  });

  document.querySelectorAll('#startMinGroup .seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      settings.startMinimized = btn.dataset.min === '1';
      saveSettings(true);
      applySettings();
    });
  });

  document.querySelectorAll('#alertsGroup .seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      settings.alertsEnabled = btn.dataset.alerts === '1';
      saveSettings(true);
      applySettings();
      if (lastLiveData) renderLive(lastLiveData);
    });
  });

  document.getElementById('alertGpuTempInput').addEventListener('change', (e) => {
    settings.alertGpuTemp = Math.max(55, Math.min(105, Number(e.target.value) || 82));
    saveSettings(true);
    applySettings();
  });

  document.getElementById('alertCpuPctInput').addEventListener('change', (e) => {
    settings.alertCpuPct = Math.max(50, Math.min(100, Number(e.target.value) || 90));
    saveSettings(true);
    applySettings();
  });

  document.getElementById('alertRamPctInput').addEventListener('change', (e) => {
    settings.alertRamPct = Math.max(50, Math.min(100, Number(e.target.value) || 90));
    saveSettings(true);
    applySettings();
  });

  document.querySelectorAll('#themeModeGroup .seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      settings.themeMode = btn.dataset.themeMode === 'light' ? 'light' : 'dark';
      saveSettings(true);
      applySettings();
    });
  });

  document.getElementById('primaryColorInput').addEventListener('input', (e) => {
    settings.primary = e.target.value;
    saveSettings(false);
    applySettings();
  });

  document.getElementById('secondaryColorInput').addEventListener('input', (e) => {
    settings.secondary = e.target.value;
    saveSettings(false);
    applySettings();
  });

  document.getElementById('glowRangeInput').addEventListener('input', (e) => {
    settings.glow = Number(e.target.value);
    saveSettings(false);
    applySettings();
  });

  // Important settings (require clicking Save Changes)
  function updateDraftZoom(nextZoom) {
    draftImportant.zoom = Math.max(75, Math.min(130, Number(nextZoom) || 100));
    syncDraftControls();
  }

  document.getElementById('zoomRangeInput').addEventListener('input', (e) => updateDraftZoom(e.target.value));
  document.getElementById('zoomOutBtn').addEventListener('click', () => updateDraftZoom((draftImportant.zoom || 100) - 5));
  document.getElementById('zoomInBtn').addEventListener('click', () => updateDraftZoom((draftImportant.zoom || 100) + 5));

  document.querySelectorAll('#langGroup .seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      draftImportant.lang = btn.dataset.lang === 'ru' ? 'ru' : 'en';
      syncDraftControls();
    });
  });

  document.querySelectorAll('#intervalGroup .seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      draftImportant.intervalMs = Number(btn.dataset.interval);
      syncDraftControls();
    });
  });

  document.getElementById('saveSettingsBtn').addEventListener('click', () => {
    settings.zoom = Math.max(75, Math.min(130, Number(draftImportant.zoom) || 100));
    settings.lang = draftImportant.lang === 'ru' ? 'ru' : 'en';
    settings.intervalMs = Number(draftImportant.intervalMs) || 1000;
    saveSettings(true);
    applySettings();
    restartLivePolling();
    showToast(t('savedToast'));
  });

  document.getElementById('discardSettingsBtn').addEventListener('click', () => {
    draftImportant = {
      zoom: settings.zoom,
      lang: settings.lang,
      intervalMs: settings.intervalMs,
    };
    syncDraftControls();
    showToast(t('discardedToast'));
  });

  document.getElementById('resetSettingsBtn').addEventListener('click', () => {
    settings = { ...DEFAULT_SETTINGS };
    draftImportant = {
      zoom: settings.zoom,
      lang: settings.lang,
      intervalMs: settings.intervalMs,
    };
    saveSettings(true);
    applySettings();
    restartLivePolling();
    showToast(t('resetToast'));
  });

  // Init + Startup Splash dismiss
  applySettings();
  syncSettingsFromServer();
  loadHardware(false);
  fetchLive();
  restartLivePolling();
  setTimeout(() => {
    const splash = document.getElementById('splashOverlay');
    if (splash) {
      splash.classList.add('fade-out');
      setTimeout(() => { splash.hidden = true; }, 420);
    }
  }, 640);
})();
